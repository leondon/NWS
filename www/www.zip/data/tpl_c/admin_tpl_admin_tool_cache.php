<?php keke_tpl_class::checkrefresh('admin/tpl/admin_tool_cache', '1411549957' );?><!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $_K['charset'];?>">
<title>keke admin</title>


<link href="tpl/css/admin_management.css" rel="stylesheet" type="text/css" />
<link href="tpl/css/button/stylesheets/css3buttons.css" rel="stylesheet" type="text/css" />
<link title="style1" href="tpl/skin/default/style.css" rel="stylesheet" type="text/css" />
<!--<link title="style2" href="tpl/skin/light/style.css" rel="stylesheet" type="text/css" />-->
<script type="text/javascript" src="tpl/js/jquery.js"></script>
<script type="text/javascript" src="tpl/js/keke.js"></script>
</head>
<body class="frame_body">
<div class="frame_content">
<div id="append_parent"></div>
<div class="page_title">
    	<h1><?php echo $_lang['update_cache'];?></h1>
          <div class="tool">         
            <a href="index.php?do=tool&view=cache" <?php if($view == 'cache') { ?>class="here"<?php } ?> > <?php echo $_lang['cache'];?><?php echo $_lang['list'];?></a> 
    	</div>
</div>
<div class="box post">
<div class="detail">
<form method="post" action="#" id="frm_cat_edit">
    <input type="hidden" name="do" value="<?php echo $do;?>"><input type="hidden" name="view" value="<?php echo $view;?>"> 
       <table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tbody>
            <tr>

                <td>
                    <label for="ckb_tpl_cache">
                        <input checked="checked" type="checkbox" id="ckb_tpl_cache" name="ckb_tpl_cache" value="1" class="checkbox"><b><?php echo $_lang['update_template_cache'];?></b>
                    </label>
                    <div class="pad10">
                    <?php echo $_lang['template_cache_notice'];?>
</div>
                </td>
            </tr>

            <tr>

                <td>
                    <label for="ckb_obj_cache">
                        <input checked="checked" type="checkbox" id="ckb_obj_cache" name="ckb_obj_cache" value="1" class="checkbox"><b><?php echo $_lang['update_object_cache'];?></b>
                    </label>
                    <div class="pad10">
                   <?php echo $_lang['object_cache_notice'];?>
   </div>
                </td>
            </tr>
</tbody>
<tfoot>
            <tr>
                <td>
                    <div class="t_c">
                        <button type="submit" name="sbt_edit" class="primary positive pill button" ><span class="check icon"></span><?php echo $_lang['update_cache_now'];?></button>

                    </div>
                </td>
            </tr>
</tfoot>
        </table>
   
</form>

</div>
</div>
 
</div>
<script type="text/javascript" src="../lang/<?php echo $language?>/script/lang.js"></script>
<script type="text/javascript" src="../static/js/xheditor/xheditor.js"></script>
<script type="text/javascript" src="tpl/js/form_and_validation.js"></script>
<script type="text/javascript" src="tpl/js/script_calendar.js"></script>
<script type="text/javascript" src="tpl/js/artdialog/artDialog.js"></script>
<script type="text/javascript" src="tpl/js/artdialog/jquery.artDialog.js?skin=default"></script>
<script type="text/javascript" src="tpl/js/artdialog/artDialog.iframeTools.source.js"></script>
<script type="text/javascript" src="tpl/js/jquery.mousewheel.min.js"></script>
<script type="text/javascript" src="tpl/js/styleswitch.js"></script>
<script type="text/javascript" src="tpl/js/table.js"></script>
<script type="text/javascript">
function cdel(o, s) {
d = art.dialog;
var c = "<?php echo $_lang['you_comfirm_delete_operate'];?>";
if (s) {
c = s;
}
d.confirm(c, function() {
window.location.href = o.href;
});
return false;
}
function cpass(o, s, type) {
d = art.dialog;
if (type == 1) {
var c = "确认审核通过？";
} else {
var c = "确认审核失败？";
}
if (s) {
c = s;
}
d.confirm(c, function() {
window.location.href = o.href;
});
return false;
}
function cfreeze(o, s, type) {
d = art.dialog;
if (type == 1) {
var c = "确认冻结？";
}
if (s) {
c = s;
}
d.confirm(c, function() {
window.location.href = o.href;
});
return false;
}
function crecomm(o, s, type) {
d = art.dialog;
if (type == 1) {
var c = "确认推荐？";
} else {
var c = "确认取消推荐？";
}
if (s) {
c = s;
}
d.confirm(c, function() {
window.location.href = o.href;
});
return false;
}
function pdel(frm) {
d = art.dialog;
var frm = frm;
var c = "<?php echo $_lang['you_comfirm_delete_operate'];?>";
d.confirm(c, function() {
$("#" + frm).submit();
});
return false;
}
function fdel(frm) {
d = art.dialog;
var frm = frm;
var c = "<?php echo $_lang['you_comfirm_delete_operate'];?>";
d.confirm(c, function() {
$("#" + frm).submit();
});
return false;
}
function batch_act(obj, frm) {
d = art.dialog;
var frm = frm;
var c = $(obj).val();
var conf = $(":checkbox[name='ckb[]']:checked").length;
if (conf > 0) {
d.confirm("<?php echo $_lang['confirm'];?>" + c + '?', function() {
$(".sbt_action").val(c);
$("#" + frm).submit();
});
} else {
d.alert("<?php echo $_lang['has_none_being_choose'];?>");
}
return false;
}
</script>
<?php if(KEKE_DEBUG) { ?>
<div
style="background-color: red; color: #fff; width: 400px; text-align: center;">
querys:
<?php echo db_factory::create()->get_query_num() ?>
&nbsp; times:
<?php echo kekezu::execute_time() ?>
</div>

<?php } ?>
</body>
</html>
<?php keke_tpl_class::ob_out();?>