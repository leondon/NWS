<?php
$lang = array (

	   'to'=>'对',

/*wbdj_work.htm*/ 
/*wbzf_work.htm*/
       'first_step'=>'第一步',
       'choose_and_login_weibo'=>'选择并登录微博',
       'second_step'=>'第二步',
       'input_info'=>'填写信息',
       'third_step'=>'第三步',
       'pub_and_submit'=>'发布交稿',
       'single_click_pub_weibo'=>'单击【发布】发送微博',
       'weibo_content'=>'微博内容',
       'picture'=>'图片',
       'release'=>'发布',
       'nickname'=>'昵称',
       'task_require'=>'任务要求',
       'to_weibo'=>'到微博',
       'the_following_few_friends'=>'以下几位好友',
       'comment_original_content'=>'评论原文内容',
       'switch_user_login'=>'切换用户登录',
       'not_repeat_the_same_people'=>'不能重复@同一个人',
	   'modify_mark_info'=>'修改稿件评分',
	   'has_viewed'=>'雇主已查看',
	   'not_vies'=>'雇主未查看',
		'good_rate'=>'好评率：',
)

?>