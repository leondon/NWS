<?php
/**
 * @version kppw2.0
 * @author xl
 */
$lang = array(
/*task_edit.php*/

	'task_operate_successfully'=>'操作成功!',
	'task_operate_fail'=>'操作失败!',
		'b_task_basic'=>'任务需求',
		'b_task_work'=>'任务稿件',
		'b_task_comm'=>'任务留言',
		'b_task_mark'=>'任务互评',
		'b_task_agree'=>'任务交付',
	'hand_time'=>'交稿时间',
	'work_status'=>'稿件状态',
	'work_delete'=>'删除稿件',
	'work_view'=>'查看稿件',
	'hide_work'=>'隐藏交稿',
	'vote'=>' 投 　 票 ',
	'comment'=>' 点 　 评 ',
	'ext_file'=>' 附 　 件 ',
	'piao'=>'票',
	'not_exists'=>'暂无',
	'load_comm'=>'载入点评',
	'load_file'=>'载入附件',
	'are_you_sure'=>'是否确认删除操作',
	'work_id'=>'稿件编号',
	'has_view'=>'已读',
	'no_view'=>'未读',
	//--- comm *****/
	'comm_id'=>'留言编号',
	'view_status'=>'查看状态',
	'comm_time'=>'留言时间',
	'delete_comm'=>'删除留言',
	'load_floor'=>'加载楼层',
	'no_data'=>'暂无数据',
 	//--mark--/
 	'mark_time'=>'评价时间',
	'mark'=>'评价',
	'no_mark'=>'暂未评价',
	/*****微博任务*******/
	'zfpt'=>'转发平台',
	'click_num'=>'点击次数',
	'wb_url'=>'微博网址：',

);