<?php
$lang = array(
/***/
	'choose_task_status'=>'请选择任务状态',
	'delay'=>'延长',

);