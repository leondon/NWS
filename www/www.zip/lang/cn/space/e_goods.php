<?php
$lang = array(
	'all_goods'=>'所有商品',
	'look_all_goods'=>'查看所有商品',
	'no_product_research'=>'对不起，暂时没有商品,您可以尝试重新搜索或者',

);