<?php
$lang = array(
//p_index.htm

	'current_value_experience'=>'当前经验值',	
	'come_from'=>'来自',
	'unknown'=>'未知',
	'sex'=>'性别',
	'ads_language'=>'广告语',
	'ability_value'=>'能力值',
	'credit_value'=>'信誉值',
	'peer_review_record'=>'互评记录',
	'pub_goods_info'=>'您还还没有发布商品,现在就去发布商品',
	'open_new_window'=>'新窗口打开',
	'collect_and_download'=>'付费并下载',
	'skills_certificate'=>'技能证书',
	'uploaded_certificate_info'=>'您还还没有上传证书,现在就去上传证书',
	'uploaded_certificate'=>'上传证书',
	'add_favorites'=>'加入收藏',
	'ability_level'=>'能力等级',
	'skill'=>'技能',
	'storekeeper'=>'小二',
	'no'=>'暂无',
	'authenticate'=>'认证',
	'witkey_task'=>'威客任务',
	'type'=>'类型',
	'time'=>'时间',
	'title'=>'标题',
	'bounty'=>'赏金',
	'visits'=>'访问量'


);