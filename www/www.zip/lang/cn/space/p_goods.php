<?php
$lang = array(
//p_goods.htm

	'open_new_window'=>'新窗口打开',
	'purchase'=>'购买',
	'selling_price'=>'售价',

);