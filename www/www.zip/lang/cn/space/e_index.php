<?php
$lang = array(
//e_index.htm

	'enterprise_info'=>'企业信息',
	'corporate_reputation_index'=>'企业信誉指数',
	'enterprise_capability_index'=>'企业能力指数',
	'certificate_of_honor'=>'证书荣誉',
	'registration_info'=>'工商注册信息',
	'xiang'=>'项',
	'view_more'=>'查看更多',
	'area'=>'所&nbsp;在&nbsp;地',
	'collection_of_company'=>'收藏本公司',
	'collection_number'=>'收藏数',
	'about_us'=>'公司介绍',
	'manuscript'=>'交稿',
	'to_task'=>'参加的任务',
	't_cash'=>'赏金',
	't_title'=>'名称',
	't_type'=>'类型',
	't_status'=>'状态',
	't_time'=>'发布时间',
	'conpany_name'=>'公&nbsp;司&nbsp;名',
	'contact_user'=>'联&nbsp;系&nbsp;人',
	'auth'=>'认&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;证',
	'e_info'=>'商铺信息',
	'credit_level'=>'信誉等级',
	'good_rate'=>'好&nbsp;&nbsp;评&nbsp;&nbsp;率',
	'cert'=>'资质证书',
	'for_sale'=>'售出',
	'goods'=>'商品',
	'supply_category'=>'热门商品分类',
	'e_search'=>'商品搜索',


);