<?php
$lang = array(
	'contact'=>'联系方式',
	'emaill'=>'邮　　箱',
	'confidential'=>'保密',
	'fax'=>'传　　真',
	'fixed_telephone'=>'固定电话',
	'mobile'=>'手　　机',
	'qq'=>'腾讯Q Q',
	'msn'=>'微软MSN'
);