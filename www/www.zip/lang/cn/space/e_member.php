<?php
$lang = array(
//e_member.htm

	'corporate_members'=>'企业成员',
		'job_position' => '职位',
		'edu_background' => '学历',
		'graduated' => '毕业院校',
		'entry_age' => '入行年限',

);