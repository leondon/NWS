<?php
$lang = array(
//e_case.htm

	'service_address'=>'服务地址',
	'industry'=>'所属行业',

);