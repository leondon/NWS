<?php
$lang = array(
//e_task.htm

	'related_task'=>'相关任务',

	'reward_task'=>'悬赏的任务',
	'to_task'=>'承接的任务',
	'title'=>'标题',
	'cash'=>'金额',
	'hand_focus_leave'=>'交稿|收藏|评论',
	'发布时间'=>'发布时间'

);