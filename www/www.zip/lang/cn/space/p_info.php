<?php
$lang = array(

//p_info.htm

	'revise_head'=>'修改头像',
	'address_space'=>'空间地址',
	'sex'=>'性　　别',
	'area'=>'地　　区',
	'date_birth'=>'出生日期',
	'personal_brief_introduction'=>'个人简介',
	'emaill'=>'邮　　箱',
	'confidential'=>'保密',
	'fax'=>'传　　真',
	'fixed_telephone'=>'固定电话',
	'mobile'=>'手　　机',
	'qq'=>'腾讯Q Q',
	'msn'=>'微软MSN',
	'occupation'=>'职　　业',
	'witkey_skills'=>'威客技能',
	'skills_certificate'=>'技能证书',
	'personal_experience'=>'个人经历',
	'matter'=>'事项',

);