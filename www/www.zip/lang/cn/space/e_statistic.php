<?php
$lang = array(
//e_statistic.htm

	'company_statistic'=>'公司统计',
	'grade'=>'等　级',
	'credit_value'=>'信誉值',
	'ability_value'=>'能力值',
	'favorable_rate'=>'好评率',
	'purchase_commodity_number'=>'购买商品数',
	'sale_goods_number'=>'出售商品数',
	'sale_goods'=>'出售商品',
	'evaluation'=>'的评价',
	'view_details'=>'查看详情',
		'nickname'=>'昵　称:',
		'rz'=>'认证：',
		'good_rate'=>'好评率：',
		'pj_name'=>'名称',
		'gz'=>'雇主',
		'witkey'=>'威客',
		'pj'=>'评价',
		'come_form_gz'=>'来自Ta人的评价',
		'come_form_witkey'=>'Ta对别人的评价',
		'come_form_yourself'=>'您对别人的评价',
		'all'=>'全部',
		'good'=>'好评',
		'middle'=>'中评',
		'bad'=>'差评',
);