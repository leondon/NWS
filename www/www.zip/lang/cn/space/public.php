<?php
$lang = array(
//space.php
	'p_home'=>'店铺首页',
	'person_info'=>'店主信息',
	 
	'user_credit'=>'信用评价',
//顶部导航
   
	'my_shop'=>'返回我的店铺',
		
	'company_info'=>'公司介绍',
	'e_member'=>'公司成员',
	'relation_task'=>'悬赏任务',
	'goods_display'=>'商品展示',
	'success_case'=>'成功案例',
	'company_total'=>'诚信档案',

//space_custom.htm
	'style_settings'=>'风格设置',
	'background_settings'=>'背景设置',
//p_nav.htm

	'space'=>'的空间',
	'custom'=>'设置',
	'address_space'=>'空间地址',
	'ci'=>'次访问',
	'visits'=>'访问量',
//e_nav.htm

	'short_message'=>'短消息',
    'replace_picture'=>'更换图片',
//e_intr.htm

	'about_us'=>'公司介绍',
	'style_set'=>'风格',
	'background'=>'背景',
	'select_file'=>'选择文件',
	'resotre_default'=>'还原为默认',
	'bg_fixed'=>'定位',
	'repeat'=>'重复',
    'not_repeat'=>'不让重复',
    'x_repeat'=>'水平方向重复',
    'y_repeat'=>'垂直方向重复',
    'scroll'=>'随页面滚动',
    'fixed'=>'固定位置',
    'upper_left_corner'=>'左上角',
    'center'=>'居中',
    'upper_right_corner'=>'右上角',
	'save_setting'=>'保存设置',
	'edit_space_fail' => '编辑空间失败',
	'successfully_set' => '设置成功',
	'fail_set' => '设置失败',
	'for_sale'=>'售出',
	'to_search_product_name'=>'请输入商品名称',
	'visited_times'=>'访问量：'
);