<?php

$lang = array(

/**/
	'choose_task_status'=>'请选择任务状态',
		'wbzf_work_hand'=>'微博转发任务交稿',
		'you_has_been'=>'您已经在',
		'no_need_rehand'=>'平台上交过一次稿件,无需重复交稿',
		'you_no_need_rehand'=>'您的微博账号已经交过一次稿件,请换一个微博账号交稿',
		'focus'=>'关注',
		'zf_this_weibo'=>'转发指定微博',
		'post_weibo'=>'发表指定微博',
		'ge_friends'=>'个好友',
		'level_yxl'=>'级影响力',
		'tools'=>'工具',
		'platform'=>'投放平台',
		'syje'=>'剩余金额',
		'task_require'=>'任务需求',
		'task_cash'=>'任务总金额',
		'fans_count'=>'粉丝数',
		'focus_count'=>'关注数',
		'wb_count'=>'微博数',
		'task_detail'=>'任务描述',
		'wb_content'=>'微博内容',
		'pic_attr'=>'图片附件',
		'click_view'=>'点击查看',
		'wbzf_task_model'=>'微博转发任务模式',
		'wbzf_task_desc'=>'微博转发任务模式，任务结束后，中标威客根据粉丝区间数获得任务赏金',
		//'zhongbiaojine'=>'中标金额',
		'cover_per'=>'覆盖度',
		'huoyue_per'=>'活跃度',
		'chuanbo_per'=>'传播度',
		'affect'=>'影响力',
		'affect_level'=>'影响等级',
		'level'=>'级',

);