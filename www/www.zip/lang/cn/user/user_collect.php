<?php
/**
 * @todo 稿件收藏
 * @author hr
 * @version kppw2.0
 * @encoding GBK
 * 2011-12-16 下午05:56:00
 */
	$lang = array(
	
	/* user_collect.php */
		'collection_of_task' => '收藏的任务',
		'collection_of_work' => '收藏的稿件',
		'collection_of_service' => '收藏的商品',
		'collection_of_case' => '收藏的案例',
		'collection_of_shop' => '收藏的店铺',
		'collection_num_desc' => '收藏编号降序',
		'collection_num_asc' => '收藏编号升序',
		'collection_time_desc' => '收藏时间降序',
		'collection_time_asc' => '收藏时间升序',
		'please_enter_the_collection_num' => '请输入收藏编号',
		'please_enter_the_collection_name' => '请输入收藏名称',
	
	/* user_collect.htm */
		'this_week' => '本周',
		'count' => '数',
		'collection_num' => '收藏编号',
		'collection_name' => '收藏名称',
		'collection_time' => '收藏时间',
	);