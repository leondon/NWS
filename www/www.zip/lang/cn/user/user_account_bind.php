<?php
/**
 * @copyright keke-tech
 * @author S
 * @version v 2.0
 * 2011-12-16
 */
$lang = array(
/*user_safe_account_bind_php*/
	'not_open'=>'第三方登录暂未开通',
    'sina_blog'=>'新浪微博',
	'tx_blog'=>'腾讯微博',
	'qq'=>'腾讯QQ',
//	'taobao_account'=>'淘定账号',
    '163_blog'=>'网易微博',
	'sohu_blog'=>'搜狐微博',
	'alipay'=>'支付宝',
	'alipay_trust'=>'支付宝担保',
	'account_been_bind'=>'这个账号已经绑定过了',
	'bind_success'=>'绑定成功',
	'bind_fail'=>'绑定失败',
	'unbind_success'=>'解除绑定成功!',
    'unbind_fail'=>'解除绑定失败',
/*user_safe_cccount_bind_htm*/

 	'account_bind'=>'账号绑定',
	'current_account'=>'当前账号',
	'multiple_account_login'=>'可以使用多个帐号进行登录',
	'been_link'=>'已链接',
	'no_link'=>'未链接',
	'unbind'=>'解除绑定',
	'to_bind'=>'开始绑定'

);