<?php
/**
 * @todo 短信发送 action
 * @author hr
 * @version kppw2.0
 * @encoding GBK
 * 2011-12-16 下午04:23:40
 */
  
	$lang = array(
	
	/* user_message_send.php */
		'fail_to_send_instation_messages' => '站内短信发送失败',
		'the_user_does_not_exist' => '您填写的用户不存在',
		'can_not_send_messages_to_yourself' => '不能给自己发送短信',
		'input_the_title' => '请填写标题',
		'input_the_content' => '请填写内容',
		'success_to_send_instation_messages' => '站内短信发送成功',
		'station_message_has_been_successfully_sent_to' => '站内短信已成功发送给',
	/* user_message_send.htm */	
		'send_message' => '发送消息',
		'addressee' => '收  信  人',
		'txt_msg_title'=>'标题长度：1-50之间',
		'please_input_the_recipients_user_name' => '请填写收信人的用户名',
		'user_name_at_least_three' => '用户名最少三位',
		'message_title' => '短信标题',
		'message_content' => '短信内容',
		'username_no_exit'=>'用户名不存在',
		'send' => '发送'
	);