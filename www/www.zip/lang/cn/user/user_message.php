<?php
/**
 * @todo 收件箱
 * @author hr
 * @version kppw2.0
 * @encoding GBK
 * 2011-12-16 下午03:57:32
 */

	$lang = array(
	
	/* user_message.php */
		'inbox' => '收件箱',
		'outbox' => '发件箱',
		'write_message' => '写短信',
		'delete_selected' => '删除所选',
		'delete_selected_success' => '成功删除所选',
		'select_null_for_delete' => '没有选择删除的项',
		'message_does_not_exist' => '该消息不存在',
		'operate_tips'=>'操作提示',
	    'biaoji_success'=>'标记成功',
		'username_not_exist'=>'用户名不存在',
	/* user_message_system.htm */
		'system_message' => '系统短信',
		'private_message' => '私人短信',
		'sms_has_been_sent' => '已发短信',
		'send' => '发送',
		'from' => '来自',
		'unread' => '未读',
		'already_read' => '已读',
		'confirm_delete' => '确认要删除？',
		'del_success'=>'删除成功!',

	/* user_message_view.htm */
		'view_message'=>'查看短信',
		'to_user'=>'收件人',
	    'biao_already'=>'标记为已读',
		'time'=>' 时　间',
		'from_user'=>' 发件人',
	    'next_tiao'=>'下一条',
	    'prev_tiao'=>'上一条',
	    'now_no'=>'暂无',
	);
  