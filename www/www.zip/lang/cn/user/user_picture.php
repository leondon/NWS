<?php
/**
 * @todo 图像设置
 * @author hr
 * @version kppw2.0
 * @encoding GBK
 * 2011-12-16 上午10:39:36
 */


	$lang = array(
	
	/* user_picture.php */
	 	'upload_head_pic' => '上传头像',
	 	'select_head_pic' => '选择头像',
	 	'the_selected_pic_is_selected' => '所选图象被选中!',
	 	'system_error_select_null' => '系统错误，图象没有被选中',

	/* user_picture.htm */
	 	'setting_head_pic' => '头像设置',
	 	'click_the_button_can_upload_your_own_pic' => ' 点击"选择图片"上传您自己的头像。',
	 	'update_pic' => '更新图片',
	 	'system_head_pic' => '系统头像',
	 	'we_chose_this' => '就选这个',
	 	'vip_head_pic' => '会员头像',
		'head_pic_view'=>'头像预览',
		'upload_check_effect'=>'上传完成之后点击"更新图片"按钮即可看见实际效果',
		'px'=>'像素',

	 );
  