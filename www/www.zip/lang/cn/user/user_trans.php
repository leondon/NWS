<?php
/**
 * @todo 交易维权
 * @author hr
 * @version kppw2.0
 * @encoding GBK
 * 2011-12-16 上午10:50:40
 */

	$lang = array(
	
	/* user_trans_rights.php */

		'record_success' => '记录成功',
		'record_fail' => '记录失败',
		'please_select_delete' => '请先选择要删除的',
	
		'rights_manage' => '维权管理',
		'rights_from_the_info_you_or_others' => '来自你或他人的维权信息',
	
		'report_manage' => '举报管理',
		'report_from_the_info_you_or_others' => '来自你或他人的举报信息',
	
		'complain_manage' => '投诉管理',
		'complain_from_the_info_you_or_others' => '来自你或他人的投诉信息',
		'num_desc' => '编号降序',
		'num_asc' => '编号升序',

	
	/* user_trans_rights.htm */
		'trading_rights' => '交易维权',
		'and_being' => '与被',
		'were_no_actual_transactions_but_found_in' => '人无实际交易产生，但发现其在',
		'there_are_irregularities_can_be' => '上有违规情况，可以通过',
		'way_to_inform' => '途径告知',
		'anonymous' => '为匿名',
		'and' => '与',
		'some_problems_can_be' => '对象可能会存在实际交易，但对其处理存在异议，可以通过',
		'the_realname' => '为实名',
		'i_initiated' => '我发起的',
		'i_received' => '我收到的',
		'pagination' => '分页显示',
		'start_time' => '发起时间',
		'current_status' => '当前状态',
		'no_contents' => '内容暂无',
		'not_submitted_attachments' => '未提交附件',
		'view_belongs' => '查看所属',
		'deleted_site_will_no_longer_accept_this_provision' => '删除后网站将不再受理此条',
		'info' => '信息',
		'temporary_without' => '暂无',
		'launch' => '发起',
		'receive' => '收到',
	);
  