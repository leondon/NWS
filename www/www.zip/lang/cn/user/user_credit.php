<?php
/**
 * @todo 信誉等级
 * @author hr
 * @version kppw2.0
 * @encoding GBK
 * 2011-12-16 上午09:53:04
 */

	$lang = array(
	
	/* user_credit.php */
	/* user_credit_grow.htm */
		'credit_growup' => '信誉成长',
		'review_each_record' => '互评记录',
		'next_level_need' => '升到下一级还需',
		'reputation_value' => '信誉值',
		'release_tasks_num' => '发布任务数',
		'task_payment' => '支付任务款',
		'goods_num' => '购买商品数',
		'payment_services_section' => '支付服务款',
		'favorable_rate' => '好评率',

		'ability_grade' => '能力等级',
		'ability' => '能力值',
		'number_of_successful_releases' => '中标稿件数',
		'get_task_models' => '获得任务款',
		'goods_sold_num' => '出售商品数',
		'access_to_services_section' => '获得服务款',
	
	/* user_credit_mark.htm */	
		'filter' => '筛选条件',
		'all_evaluation' => '所有评价',
		'praise' => '好评',
		'the_assessment' => '中评',
		'negative_feedback' => '差评',
		'to_be_evaluated' => '待评价',
		'evaluation_from_others' => '来自他人评价',
		'evaluation_of_others' => '对他人的评价',
		'witkey_identity' => '威客身份',
		'employer' => '雇主身份',
		'from' => '来自',
		'to' => '对',
		'didnot_respond_to_evaluation' => '未回复评价',
		'view_the_task_details' => '查看任务详细',
		'view_the_goods_details' => '查看商品详细',
		'view_the_hire_details' => '查看雇佣详细',
		'no_comments' => '暂无评论',
		'shop'=>'商品',
		'task'=>'任务',
		'hp'=>'互评内容： ',
		'check_evalue'=>'查看辅助评价',
	/* user_credit.htm */
		'project_name'=>'项目名称',
		'task_goods'=>'(任务|商品)',
		'evaluate'=>'评价',
		'come_from'=>'来自',
		'assisted_evaluation'=>'辅助评价',
	);
  