<?php
/**
 * @todo 发件箱
 * @author hr
 * @version kppw2.0
 * @encoding GBK
 * 2011-12-16 下午04:13:10
 */
  
	$lang = array(
	
	/* user_message_outbox.php */
		'inbox' => '收件箱',
		'outbox' => '发件箱',
		'write_message' => '写短信',	
		'delete_selected' => '删除所选',
		'delete_selected_success' => '成功删除所选',
		'select_null_for_delete' => '没有选择删除的项',
		'message_does_not_exist' => '该消息不存在',	
	/* user_message_outbox.htm */
		'system_message' => '系统短信',
		'private_message' => '私人短信',
		'sms_has_been_sent' => '已发短信',	
		'send' => '发送',
		'addressee' => '收件人',
		'confirm_delete' => '确认要删除？',

	);