<?php
/**
 * @todo 增值服务
 * @author hr
 * @version kppw2.0
 * @encoding GBK
 * 2011-12-16 上午10:19:30
 */

	$lang = array(
	
	/* user_payitem.php */


		'record_num_desc' => '记录编号降序',
		'record_num_asc' => '记录编号升序',
		'produce_desc' => '产生时间降序',
		'produce_asc' => '产生时间升序',
	
	/* user_payitem_buy.htm */
		'value_added_services' => '增值服务',
		'make_you_more_competitive' => '购买威客增值服务，让您更加具有竞争力',
		'according_to' => '按',
		'charge' => '收费',
// 		'buy_now' => '立刻购买',
	/* user_payitem_list.htm */
		'num' => '编　　号',
		'input_record_num' => '请输入记录编号',
		'type_of_service' => '服务类型',
		'all' => '所有',
		'type_of_use' => '使用类型',
		'buy' => '购买',
		'use' => '使用',
		'order_by' => ' 排序显示',
		'record_num' => '记录编号',
		'the_amount_spent' => '花费金额',
		'count' => '数量',
		'remain'=>'剩余：',
		'use_time' => '使用时间',
		'buy_time' => '购买时间',
	/**user_toolbox_buy.htm**/
		'tool_name'=>'工具名称',
		'cash_idea'=>'收费策略',
		'in_use'=>'使用范围',
		'shop1'=>'商品',
	    'task'=>'任务',
	    'work'=>'稿件',
	    'now_no1'=>'暂无',
	);