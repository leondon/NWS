<?php
/**
* 订单交易
*@author deng
*@version KPPW 2.0
*@charset:GBK
*2011-12-16 下午04:52:12
*/
$lang=array(
/*user_finance_order.php*/
      'both_mark'=>'双方互评',
      'works_file_upload'=>'作品文件下载',
	  'confirm_pay'=>'确认付款',
      'wait_pay'=>'待付款',
      'has_pay'=>'已付款',
      'pay_fail'=>'付款失败',
      'trans_close'=>'交易关闭',
      'wait_buyer_pay'=>'等待买家付款',
      'buyer_has_pay'=>'买家已付款',
      'seller_has_accept'=>'卖家已接受',
      'seller_has_severice'=>'卖家已服务',
      'confirm_complete'=>'确认完成',
      'order_arbitral'=>'订单仲裁',
      'please_input_order_name'=>'请输入订单名称',


/*user_finance_order.htm*/
      'order_manage'=>'订单管理',
      'task_trans'=>'任务交易',
      'i_order'=>'我下单的',
      'i_receive'=>'我收到的',
		'other_operate'=>'其他 操作',
      'order_name'=>'订单名称',
      'after_sales'=>'售后',
      'single_price_yuan'=>'单价(元)',
      'trans_status'=>'交易状态',
      'trans_operate'=>'交易操作',
   	  'confirm'=>'确认',

      'pub_time'=>'提交时间',
      'send_message'=>'发短信',
      'complaints_rights'=>'投诉维权',
      'view_detail'=>'查看详情',
      'operate_wait_do'=>'操作待做',
      'go_pay'=>'去付款',
      'confirm_delete_order'=>'确认删除此订单',
      'order_delete_fail'=>'订单删除失败',
   //扩展的
   	'buy_in'=>'买入的商品',
   	'sell_out'=>'卖出的商品',
   	'buy_goods'=>'购买商品',
   	'sell_goods'=>'卖出商品',
   	'contant'=>'请联系卖家索要作品,然后再确认作品,卖家联系方式:',
   	'get_pay'=>'请尽快联系买家确认作品,以便能快速收款!',
    'shop_model_close'=>'商品模块已被关闭、无可用数据',
    'pingjia_error'=>'您已经评价过两次了不能再评价',
    'msg_tishi'=>'消息提示',

);
