<?php
/**
*
*@author xl
*@version KPPW 2.0
*@charset:GBK
*2011-12-16 下午02:41:54
*/

$lang=array(
/**user_finance_prom.php**/
	'prom_id_desc'=>'推广编号降序',
	'prom_id_asc'=>'推广编号升序',
	'gain_cash_desc'=>'获得金额降序',
	'gain_cash_asc'=>'获得金额升序',
	'input_prom_id'=>'请输入推广编号',
	'relation_id_desc'=>'关系ID降序',
	'relation_id_asc'=>'关系ID升序',
	'prom_time_desc'=>'推广时间降序',
	'prom_time_asc'=>'推广时间升序',
/**user_finance_prom.htm**/

      'prom_profit'=>'推广收益',
      'prom_relation'=>'推广关系',
      'prom_total_income'=>'推广的总收入',
      'prom_relation_notice'=>'推广关系提示：下线就是被推广人。',
      'please_input_prom_id'=>'请输入推广编号',
      'event_id'=>'事项ID',
      'prom_event'=>'推广事项',
      'prom_downline'=>'推广下线',
      'get_money'=>'获得金额',
      'event_status'=>'事项状态',
      'please_input_relation_id'=>'请输入关系编号',
      'relation_type'=>'关系类型',
      'prom_time'=>'推广时间',
      'relation_status'=>'关系状态',      
      'relation_id'=>'关系编号',


);