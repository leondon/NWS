<?php

$lang = array(
	'type_no_empty'=>'type不能为空!',
	'login_in_fail'=>'登陆失败',
	'login_account_fail'=>'注册帐号失败',
	'now_three_account_bind'=>'当前的第三方账号已被绑定',
	'account_bind'=>'绑定已有账号',
	'improve_information'=>'完善个人信息',
	'you_user_account'=>'您使用的账号',
	'account'=>'账　号：',
	'you_can_use_more_login_way'=>'您可以使用手机号/email/用户名',
	'user_error'=>'用户名输入错误',
	'username_can_zh'=>'用户名可以为中文!',
	'this_accout_used_login'=>'此账号 用于登录及找回密码，不会公开',
	'pwd'=>'密　码：',
	'pwd_msg'=>'密码长度不能低于6位',
	'pwd_title'=>'密码长度为6-20位',
	'input_six_str'=>'请输入6-16个字符',
	'code'=>'验证码：',
	'code_error'=>'验证码错误!',
	'input_code'=>'请输入验证码',
	'now_bindding'=>'立 即 绑 定',
	'login_agreen'=>'登录协议',
	'rights_pub'=>'和版权声明',
	'use_friend_web_login'=>'使用合作网站账号登录',
	'i_has_read_and_accept'=>'我已阅读并接受',

);