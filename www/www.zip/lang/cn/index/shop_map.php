<?php
/**
 * 任务列表页页语言包
 * 数组键的定义:
 * 单词与单词之间必须用下划线来连接,首字母必须用小写，适用于所有的lang数组；
 * @version kppw2.0
 * @author xl
 */

$lang = array(
/*shop_map.php*/
    'works_code'=>'作品（源码）',
	'nearly_a_day'=>'近一天',
	'nearly_three_day'=>'近三天',
	'nearly_a_week'=>'近一周',
	'nearly_a_month'=>'近一个月',
	'task_releaser'=>'任务发布人',
    'front_release'=>'前发布',

/*shop_map_baidu.htm*/
/*shop_map_google.htm*/
    'goods_list'=>'商品列表',
    'shop_map'=>'商城地图',
    'area_search'=>'地区搜索',
    'goods_class'=>'商品分类',
    'goods_kinds'=>'商品种类',
    'goods_money'=>'商品金额',
	/*****************/
		'back_to_shop_list'=>'返回商城列表',
		
		
);