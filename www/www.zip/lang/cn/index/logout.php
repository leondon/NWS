<?php

$lang = array(
	'info_notice'=>'信息提示',
	'logout_success'=>'您已成功退出',

);