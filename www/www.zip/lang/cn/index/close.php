<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-1-16 下午03:04:00
*
*/
$lang=array(
/*close.htm*/
      'the_site_has_been_closed'=>'该网站已关闭',
      
);
