<?php

	$lang = array(
	/*wb.php*/
   
		'focus_success'=>'关注成功',
		'focus_exists'=>'已关注',
 
 
	);