<?php
$lang = array(
/*login.html*/
      'no_account_now_register'=>'无账号？现在去注册',
      'register_success_to_login'=>'账号注册成功后，通过邮箱认证和手机认证之后，就可以通过邮箱和手机来登录啦!',
      'need_to_logined'=>'您所访问的页面需要登录',
		'account'=>'账　号：',
      'password'=>'密　码：',
      'you_can_user_phone_eamil'=>'手机号/邮箱/用户名',
	  'input_your_user_name'=>'填写您的用户名',
      'user_error'=>'用户名输入错误',
      'username_can_chinese'=>'用户名可以为中文!',
      'login_and_find_password_use'=>'登录及找回密码用，不会公开',
      'password_length_limit'=>'密码长度不能低于6位',
      'password_length'=>'密码长度为6-20位',
      'six_to_sixteen_char'=>'6-16个字符',
      'find_back_password'=>'找回密码',
      'i_has_read_and_accpet'=>'我已阅读并接受',
		'report_msg'=>'请阅读登录协议',
      'login_agreement'=>'登录协议',
      'and_copyright_notice'=>'和版权声明',
      'from_cooperation_website_login'=>'通过合作网站直接登录',
		'password_is_not_null'=>'密码不可以为空',
		'one_week_auto_login'=>'一周内自动登录',
	  'in_order_account_security_not_check_on_public'=>'为了账户安全，请勿在公用电脑上勾选此项',




















);