<?php
$lang = array(
	'illegal_in_no_exits'=>'非法进入，不存在此交付协议',
	'wain_you_no_double'=>'警告,您不是雇佣双方,无法进入此页面',
	'now_model_no_exits_no_in'=>'当前任务模型不存在或已关闭,无法进入交付页面，请联系管理员解决',


);