<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-1-16 下午03:04:00
*
*/
$lang=array(
/*case.html*/
      'case'=>'案例',
      'success_case'=>'成功案例',
      'sales_volume'=>'销量',
      'submit_works'=>'交稿',
      'case_type'=>'案例类型',
      'view_detail'=>'查看详情',
	
);
