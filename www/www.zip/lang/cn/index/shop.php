<?php 
/**
 * 数组键的定义:
 * 单词与单词之间必须用下划线来连接,首字母必须用小写，适用于所有的lang数组；
 * @version kppw2.0
 * @author lj
 * 
 */
$lang = array(
/*shop.htm*/
	'weike_shop'=>'威客商城',
    'shop_list'=>'商城列表',
    'shop_map'=>'商城地图',
    'hot_class'=>'热门分类',
    'hot_recommend'=>'热门推荐',
    'newest_goods'=>'最新商品',
    'high_money_goods'=>'高金额商品',
    'order_is_ongoing'=>'交易正在进行',
    'view_all_goods'=>'查看所有商品',
    'buy_times'=>'购买次数',
    'view_goods_detail'=>'查看商品详情',
    'pay_money_download_goods'=>'付费下载商品',
);
