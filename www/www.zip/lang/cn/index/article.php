<?php 
/**
 * 文章语言包
 * 数组键的定义:
 * 单词与单词之间必须用下划线来连接,首字母必须用小写，适用于所有的lang数组；
 * @version kppw2.0
 * @author xl
 * 
 */

$lang = array(
 	 'view_num'=>'次浏览',
		'author'=>'作者',
		'source'=>'来源',
		'ym'=>'佚名',
		'wz'=>'未知',
	'view_artilce'=>'阅读全文',
	'text_size'=>'文字大小',
	'art_detail'=>'文章详细',
	'news_title'=>'新闻标题',
	     
	'classify'=>'分类',
	'part'=>'归档',
	'year_part'=>'年归档',
/**article_info.php**/
	'view_article'=>'查看文章',
/**article_index.htm**/
	'recommend'=>'[荐]',
	'picture'=>'[图]',
);