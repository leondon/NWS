<?php
/**
 * @copyright keke-tech
 * @author hr
 * @version v 2.0
 * @encoding GBK
 */
  
	$lang = array(
			'using_mouse_wheel' => '使用鼠标滚轮，滚动页面查看更多信息',
			'login_now' => '现在就登录',
			'mobi_version' => '手机版',
			'immediate_phone_access' => '立即使用手机访问，获得极速移动体验',
			'quickly_visit' => '快速访问',
			'quickly_access_via' => '您可以通过手机快速访问威客网站，随时随地查看最新信息。',
			'more_efficient' => '接任务更快捷',
			'more_convenient' => '通过手机版，可以更加快速的发布和承接任务，让您不在电脑旁也能参与任务。',
			'mobile_browse' => '多移动设备浏览',
			'tips_about_mobile_version' => '手机版除了支持各种智能手机直接访问，同时支持目前市面流行的各种移动设备访问，根据浏览显示分辨率不同得到不一样的访问效果。'
			);