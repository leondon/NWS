<?php
	$lang = array(
	/*weibo.php*/
   		'weibo_market'=>'微博营销',
		'blog_click_task'=>'微博点击',
		'blog_forward_task'=>'微博转发',
 		'blog_taobao_task'=>'淘宝任务',
		'taobao_weibo'=>'淘宝微博',
		'click'=>'点',
		'forward'=>'转',
		'taobao'=>'淘',
		'doing'=>'在',
		'i_want_publish'=>'我要发布',
		'i_want_spread'=>'我要传播',
		'they_are_doing'=>'TA们正在',
		'post_microblog'=>'发布微博',
		'task'=>'任务',
		'released'=>'发布了',
		'before_release'=>'前发布',
		'they_get_reward'=>'TA们获得了赏金',
		'successful_bidder'=>'中标获得',
		'hot_activities'=>'热门活动',
		'need_more_help'=>'需要更多帮助请查看',
		'hotline'=>'咨询热线：027-87733922',
 
	);