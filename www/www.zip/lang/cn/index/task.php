<?php

	$lang = array(
	/*task.php*/
   
		'task_auditing'=>'任务审核中',
		'task_not_exsit_has_delete'=>'任务不存已删除',
		'task_model_not_exist'=>'任务模型不存在或已禁用',
	
	/*task.html*/
		'new_task'=>'最新任务',
		'hot_class'=>'热门分类',
		'hot_recommend'=>'热门推荐',	
		'hour_task'=>'小时任务',
		'high_money_task'=>'高金额任务',	
		'alliance_task'=>'联盟任务',
		'ge_order_ongoing'=>'个交易正在进行',	
		'view_all_task'=>'查看所有任务',
		'people_view'=>'人查看',	
		'people_submit'=>'人投稿',
		'after'=>'后',	
		'bid'=>'投标',
		'submit_works'=>'交稿',
		'stop'=>'停止',
		'choose_bid'=>'选标',
		'choose_works'=>'选稿',
		'i_want'=>'我要',
		'task_not_pay'=>'任务未付款',
	    'operate_disable_notice'=>'操作无效，用户向自己发布的任务投稿!',
	    'operate_fail_notice'=>'操作失败提示',
	);