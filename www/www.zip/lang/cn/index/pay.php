<?php
$lang = array(
	'this_order_no_wait'=>'此订单不是待付款订单',
	'this_order_need_pay'=>'此订单不需充值即可付款',
	'order_pay'=>'订单支付',
	'order_name'=>'订单名称',
	'order_cash'=>'订单金额',
	'order_id'=>'订单号:',
	'user_remain_cach'=>'用户余额:',
	'you_should_pay_cach'=>'您应支付的总金额为',
	'choose_pay_way'=>'请选择支付方式',
	'devel_account'=>'可选账户',
	'now_pay'=>'立即支付',
    'pay'=>'支付',
    'confirm_pay'=>'确认支付',
	'pay_tips'=>'线下支付方式未开启，请联系网站管理员开启后方可使用',
	

);