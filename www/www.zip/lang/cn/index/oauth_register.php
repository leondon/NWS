<?php

$lang = array(

	'type_no_empty'=>'type不能为空!',
	'account_bind'=>'绑定已有账号',
	'improve_information'=>'完善个人信息',
	'you_user_account'=>'您使用的账号',
	'account'=>'账　&nbsp;&nbsp;&nbsp;&nbsp;                  号：',
	'username_no_mobile_email'=>'2-20个字符，一个汉字为两个字符，推荐使用中文会员名。',
	'username_input_wrong'=>'用户名输入有误',
	'input_your_accout'=>'请输入注册账号（不能为手机号和email）',
	'email'=>'邮　&nbsp;&nbsp;&nbsp;&nbsp;                  箱：',
	'email_msg'=>'请输入您真实的邮箱地址',
	'email_title'=>'请输入您常用的邮箱',
	'input_your_email'=>'请输入邮箱号码',
	'pwd'=>'密　&nbsp;&nbsp;&nbsp;&nbsp;                  码：',
	'pwd_msg'=>'密码长度不能低于6位',
	'pwd_title'=>'密码长度为6-20位',
	'input_pwd'=>'请输入密码',
	'confirm_pwd'=>'确认 密码：',
	'confirm_pwd_wrong'=>'重复密码不正确',
	'input_confirm_pwd'=>'请重复输入密码',
	'please_confirm_pwd'=>'请确认密码',
	'code'=>'验 &nbsp;&nbsp;证&nbsp;&nbsp;码：',
	'please_input_register_pw'=>'6-20个字符，请使用字母加数字或符号的组合密码',
	'code_error'=>'验证码错误!',
	'input_code'=>'请输入验证码',
	'improve'=>'完　  善',
	'rigister_agree'=>'注册协议',
	'rights_pub'=>'和版权声明',
	'use_friend_web_login'=>'使用合作网站账号登录',
	'i_have_read_and_recept'=>'我已阅读并接受',
	'general'=>'中',
	'better'=>'强',
	'weak'=>'弱',











);