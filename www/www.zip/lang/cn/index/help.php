<?php 
/**
 * 数组键的定义:
 * 单词与单词之间必须用下划线来连接,首字母必须用小写，适用于所有的lang数组；
 * @version kppw2.0
 * @author lj
 * 
 */
$lang = array(
	'you_want_know'=>'想了解什么?',
	'kf_tel'=>'客服热线电话',
	'in_total'=>'共有',
	'match_result'=>'条匹配结果',
);
