<?php
$lang = array(
	'service_tools'=>'服务工具',
	'service_name'=>'服务名称',
	'haved_buy'=>'已购买',
	'service_atr'=>'服务属性',
	'haved_set_task_area'=>'已设置任务地区',
	'set_area'=>'设置区域',
	'use_times_not_more_buy'=>'使用次数不能超过购买次数',
	'input_times_error'=>'您输入的次数有误',
	'arter_buy_and_use'=>'购买后才能使用 ',
	'buy'=>'购买',
	'choose_map_area'=>'请选择地图区域',
	'remain'=>'还剩',
	'use'=>'使用',
	'you_can_not_access_this_page'=>'您不能访问此页面',

);