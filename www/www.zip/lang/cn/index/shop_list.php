<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-1-16 上午11:43:37
*/

$lang=array(
/*shop_list.html*/
      'goods_list'=>'商品列表',
	  'shop_classify'=>'商城分类',
      'shop_map'=>'商城地图',
      'shop_hall'=>'商城大厅',
      'goods_class'=>'商城分类',
      'goods_type'=>'商品类型',
      'goods_kinds'=>'商品种类',
      'goods_money'=>'商品金额',
      'user_defined'=>'自定义',
      'reward_goods'=>'悬赏商品',
      'author_description'=>'卖家|描述',
      'has_sell_or_price'=>'价格|已出售',
	  'shop_dt'=>'商城动态',
      'works'=>'作品',
      'selled'=>'成功售出',
	  'records'=>'笔',
      'task_trends'=>'任务动态',
	  'the_address_has_collection'=>'该地址已被收藏',
	  'shop_name'=>'商品名称',
      'you_no_search_history'=>'您暂无搜索历史',
	  'goods_info'=>'商品信息',
		'low_price_former'=>'低出售价格在前',
		'high_price_former'=>'高出售价格在前',

/*shop_list.php*/
      'works_code'=>'作品（源码）',
      'nearly_a_day'=>'近一天',
      'nearly_three_day'=>'近三天',
      'nearly_a_week'=>'近一周',
      'nearly_a_month'=>'近一个月',
      'task_pub_people'=>'任务发布人',
);