<?php
$lang = array(
     /*excite_email.php*/
     'your_username_has_activation_seccess'=>'您的账号已成功激活',
     'user_activation_number_error'=>'用户激活码错误',
     'your_username_activation_fail'=>'您的账号激活失败',
     'your_username_activated_not_repeat'=>'您的账号已被激活，请勿重复操作',
     'not_exist_wait_activation_user'=>'不存在的待激活用户',
);