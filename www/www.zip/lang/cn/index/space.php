<?php 
/**
 * 数组键的定义:
 * 单词与单词之间必须用下划线来连接,首字母必须用小写，适用于所有的lang数组；
 * @version kppw2.0
 * @author lj
 * 
 */
$lang = array(
	//e_upPic.htm
    'picture_upload'=>'图片上传',
    'picture_save_success'=>'图片保存成功',
    'success_notice'=>'成功提示',
    'picture_save_fail'=>'图片保存失败',
    'this_user_no_open_space'=>'该用户还没有开通店铺',
    'insufficient_permissions'=>'权限不足!',
    'change_the_slide'=>'更改幻灯片',
);
