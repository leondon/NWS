<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-2-13 下午02:46:25
*/
$lang=array(
       'freeze_notcie'=>'冻结通知',
       'you_pub_task'=>'您发布的任务',
       'has_freeze'=>'被冻结!',
		'username'=>'用户名',
		'action'=>'动作',
		'reson'=>'原因',
		'admin_frize'=>'管理员冻结',
		'task_title'=>'任务标题',
		'sitename'=>'网站名称',
       'unfreeze_task'=>'解冻任务',
       'task_unfreeze_notice'=>'任务解冻通知',
       'has_unfreeze'=>'被解冻!',
       'audit_task'=>'审核任务',
       'pass'=>'通过',
       'task_audit_notice'=>'任务审核通知',
       'audit_pass'=>'审核通过!',
       'not_pass'=>'未通过',
		'task_unfrize'=>'任务解冻',
       'audit_not_pass'=>'审核未通过!',
       'delete_task'=>'删除任务',
       'pass_audit'=>'通过审核',
       'no_pass_audit'=>'不通过审核',
       'freeze_task'=>'冻结任务',
       'unfreeze_task'=>'解冻任务'
);