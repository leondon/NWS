<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-2-13 上午11:51:43
*/
$lang=array(
       'please_choose_son_industry'=>'请选择子行业',
       'service_type'=>'服务类型',
       'goods_link'=>'商品链接',
       'goods_status'=>'商品状态',
       'has_pub_goods'=>'发布了商品 ',
       'no_choose_goods_model_notice'=>'您没有选择商品模式,无法进入此页面',
       'no_input_goods_need_notice'=>'您没有填写商品需求,无法进入此页面',
       'page_expired_notice'=>'此页面已过期,无法进入此页面,现在跳往发布页面',
       'pieces'=>'件',
       'copy'=>'份',
       'hour'=>'小时',
       'week'=>'周',
       'month'=>'月',
       'release_tips'=>'发布提示'
);