<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-2-11 上午11:54:38
*/
$lang=array(
      'msg_notice'=>'消息提示',
      'user_id'=>'用户id',
      'sms_send_success'=>'短信发送成功!',
      'sms_send_fail'=>'短信发送失败!',
);