<?php
$lang = array(
	'congratulate_you_yu'=>'恭喜：您于',		
	'congratulate_each_yu'=>'恭喜：对方于',
	'agree_jf_agreement'=>'同意交付协议。',
	'each_mark'=>'双方互评',
	'wait_agreement'=>'待签署协议',
	'jf_complete'=>'交付完成',
	'wain_each_not_agree_and_wait_jf'=>'警告：对方还没有同意协议，交接等待中。',
	'confirm_jf_resource_file'=>'确认交付了源文件',
	'confirm_recept_resource_file'=>'确认收到了源文件。',
	'waiting_each_confirm_jf_resource_file'=>'正在等待对方确认交付源文件。',
	'delivery_time_out'=>'雇佣双方超时未完成交付或交付期申请了仲裁,交付阶段已被冻结。如果未进行仲裁申请，请双方提交仲裁申请,以方便客服介入。',
	
);