<?php
$lang = array(
	'apply_fail_and_info_fail'=>'申请提交失败，关联账户资料获取失败',
	'input_your_get_cash'=>'请输入您卡中收到的打款金额',
	'input_cash_not_equal_admin_cash'=>'您填写的收款金额与管理员打款金额不相等，',
	'no_pass_connect_kf'=>'未通过，请与客服联系',


);