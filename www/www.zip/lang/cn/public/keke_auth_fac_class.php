<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-2-13 上午10:29:57
*/
$lang=array(
       'has_pass'=>'已通过',
       'not_pass'=>'未通过',
       'auth_item_exist_add_fail'=>'认证项目增加失败,该项已存在',
       'add_auth_item'=>'增加认证项目',
       'auth_item_add_success'=>'认证项目增加成功',
       'unknow_error_add_fail'=>'目录不存在或配置错误，添加失败',
       'delete_auth_item'=>'删除认证项目',
       'auth_item_delete_success_notice'=>'认证项目删除成功',
       'auth_item_delete_fail'=>'认证项目删除失败',
       'delete_auth_item'=>'删除认证项目',
       'auth_item_mulit_delete_success'=>'认证项目批量删除成功',
       'auth_item_mulit_delete_fail'=>'认证项目批量删除失败',
       'auth_item_edit_fail_notice'=>'认证项目编辑失败,不存在的认证项',
       'edit_auth_item'=>'编辑认证项目',
       'auth_item_edit_success'=>'认证项目编辑成功',
       'auth_item_edit_fail'=>'认证项目编辑失败',
);