<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-2-11 下午12:01:38
*/
$lang=array(
      'your_balance_not_enough'=>'您的余额不足',
      'month'=>'月',
);