<?php
$lang = array(
	'tx_pay_success_notice'=>'提现打款成功通知',
	'tx_pay_fail_notice'=>'提现打款失败通知',
	'tx_success'=>'提现成功',
	'sitename'=>'网站名称',
	'tx_cash'=>'提现金额',
	'tx_fail'=>'提现失败',
	'your_alipay_tx_apply_notice'=>'您的支付宝提现申请网站已经受理并打款，金额为：￥',
	'yusn_check_your_accout'=>'元。请登陆支付宝查收',
	'tx_pay_fail_case_is'=>'您的支付宝提现申请网站已经受理并打款，此次打款失败。失败原因为：',

);