<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-2-11 上午09:21:29
*/
$lang=array(
      'file_not_exist'=>'文件不存在',
);