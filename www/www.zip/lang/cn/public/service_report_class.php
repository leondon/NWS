<?php
$lang = array(
	'deal_fail_and_not_part_cash'=>'处理失败,当前无法进行赏金分配',
);