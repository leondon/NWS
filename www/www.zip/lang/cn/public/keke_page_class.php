<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-2-11 上午09:30:44
*/

$lang=array(
      'first_page'=>'第一页',
      'Previous_page'=>'上一页',
      'page'=>'页',
      'next_page'=>'下一页',
      'last_page'=>'最后一页',
);