<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-2-13 上午11:17:38
*/
$lang=array(
			'witkey_task_exist_error'=>'威客合作网站任务已存在',
			'witkey_recharge_exist_error'=>'威客合作网站任务赏金已支付',
			'recharge_info_modified'=>'充值数据被修改',
			'platform_authority_illegal'=>'操作权限限制',
			'witkey_recharge_id_empty'=>'任务充值id为空',
			'witkey_recharge_empty'=>'任务充值记录为空',
			'witkey_task_not_exist'=>'任务不存在',
			'witkey_transfer_not_exist'=>'转账不存在',
			'witkey_transfer_already_exist'=>'转账已存在',
			'witkey_amount_not_match'=>'金额不匹配',
			'task_lef_amount_not_enough'=>'剩余金额不足',
			'witkey_count_not_match'=>'笔数不匹配',
			'witkey_not_allow'=>'中标者不允许撤销',
			'witkey_outer_transfer_already_paid'=>'合作网站转账流水已支付',
			'witkey_outer_transfer_repeat'=>'合作网站转账流水号重复',
			'witkey_data_not_match'=>'数据不匹配',
			'witkey_data_validate_failure'=>'数据校验失败',
			'bidder_equals_task_creator_error'=>'中标者不能与发布者相同',
			'account_query_error'=>'账号查询错误',
			'account_not_exist'=>'账号不存在',
			'parameter_is_incorrect'=>'参数不正确',
			'digital_inspection_signed_fail'=>'数字验签失败',
			'system_error'=>'客客系统错误',
			'connection_timed_out_error'=>'连接超时错误',
			'partner_error'=>'partner错误',
			'no_rights_access_interface'=>'无权访问该接口',
			'interface_info_not_exist'=>'接口信息不存在',


);