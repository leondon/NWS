<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-2-11 下午03:37:55
*/
$lang=array(
       'you_has_to_this_user'=>'您已对此用户进行过',
       'please_not_repeat_operate'=>'请勿重复操作',
       'this_task_has_delete'=>'该任务已被删除',
       'order_rights_id'=>'交易维权编号',
       'order_rights_name'=>'交易维权名称',
       'order_rights_type'=>'交易维权类型',
       'order_rights_object'=>'交易维权对象',
       'attention_follow'=>'关注跟进',
       'process_result'=>'处理结果',
       'process_notice'=>'处理通知',
       'order'=>'订单',    //  2 
       'launch_people'=>'发起方',
       'submit_reason'=>'提交原因',
       'freeze_notice'=>'冻结通知',
       'rights'=>'维权',
       'rights_process_notice'=>'维权处理通知',
       'ability_value'=>'能力值',
       'credit_value'=>'信誉值',
       'submit_success_wait_website_process'=>'提交成功,请等待网站受理',
       'submit_fail'=>'提交失败',
       'report'=>'举报',
       'complaints'=>'投诉',
       'wait_process'=>'待处理',
       'processing'=>'处理中',
       'no_set_up'=>'未成立',
       'has_process'=>'已处理',
	   'accepted_notice'=>'受理通知',
);