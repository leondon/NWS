<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-2-13 上午10:54:37
*/
$lang=array(
       'order_delete_success'=>'订单删除成功',
       'order_delete_fail'=>'订单删除失败',
       'buyer_can_not_to_self'=>'买家无法对自己发起',
       'seller_can_not_to_self'=>'卖家无法对自己发起',
       'no_trans_not_to_order'=>'非交易双方无法对订单发起',
       'wait_confirm'=>'待确认',
       'has_pay'=>'已付款',
       'pay_fail'=>'付款失败',
       'trans_close'=>'交易关闭',
       'task_trans'=>'任务交易',
       'payitem_service'=>'增值服务',
       'goods_trans'=>'商品交易',
       'bounty_hosting'=>'赏金托管',
);