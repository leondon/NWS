<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-2-11 上午11:48:33
*/
$lang=array(
      'tag'=>'标签',
      'not_found'=>'未找到',
      'ad_leasing'=>'广告位招租',
      'pixels'=>'像素 '
);