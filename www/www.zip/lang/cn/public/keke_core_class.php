<?php


$lang=array(
      'collection_success'=>'收藏成功',
      'collection_fail'=>'收藏失败',
      'you_not_login_not_operate'=>'您还没有登录,无法执行此操作',
      'you_can_not_collection_self'=>'您无法收藏自己的',
      'you_has_collection_this'=>'您已经收藏了此',
      'no_need_continue_collection'=>'无需继续收藏',
      'million'=>'万',
      'in'=>'在',
      'before'=>'前',
      'just'=>'刚刚',
      
      'site_is_close_notice'=>'站点已被管理员关闭，暂时无法访问',
      'site_close_reason_notice'=>'站点已被管理员关闭，关闭原因：',
      'credit'=>'代金券',
      'experience'=>'经验值',

);