<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-2-11 下午03:18:19
*/
$lang=array(
       'congratulation_you_mark_success'=>'恭喜您互评成功',
       'sorry_mark_fail'=>'对不起，互评失败',
       'sorry_fail_level_not_down'=>'对不起，互评失败，互评等级只能往上调',
       'level'=>'等级',
       'ability_value'=>'能力值',
       'credit_value'=>'信誉值',
       'title'=>'头衔'
);
