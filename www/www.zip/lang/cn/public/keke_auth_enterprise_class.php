<?php
$lang = array(
	'space_name'=>'空间名',
	'space_changed'=>'空间变更',

);