<?php
$lang = array(
	'user_recharge'=>'用户充值',
	'recharge_account'=>'充值金额',
	'online_recharge_success'=>'在线充值成功',
	'online_recharge_fail'=>'在线充值失败',
	'order_id_mh'=>'订单编号：',
	'pay_account_mh'=>'充值金额：',
	'pay'=>'支付',


);