<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-2-11 上午11:10:49
*/
$lang=array(
      'text'=>'文本',
      'radio'=>'单选',
      'select'=>'下拉',
      'check'=>'多选',
      'int'=>'整数',
      'float'=>'小数',
      'digit'=>'数字',
      'timestamp'=>'时间戳',
      'idcard'=>'身份证',
      'mail'=>'邮件'
);