<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-2-13 上午10:02:17
*/
$lang=array(
       'upload_fail_picture_width_is'=>'上传失败,当前图片宽度为',
       'picture_limit_width'=>'图片限制宽度为',
       'picture_adjust_and_then_upload'=>'图片不符合指定要求，请调整后再上传!',
       'upload_fail_picture_heigth'=>'上传失败,当前图片高度为',
       'picture_limit_height'=>'图片限制高度为',
);
