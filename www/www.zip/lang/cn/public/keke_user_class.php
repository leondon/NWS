<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-2-11 下午02:03:56
*/
$lang=array(
      'activate_the_account'=>'激活账号',
      'username_is_empty'=>'用户名为空',
      'username_illegal'=>'用户名非法',
      'user_has_exist'=>'用户已经存在',
		'user_has_no_exist'=>'用户不存在',
      'contain_allow_register_words'=>'包含要允许注册的词语',
      'username_invalid'=>'用户名无效',
      'register_fail_limit_register'=>'注册失败，用户名限制注册',
      'email_format_error'=>'email 格式有误',
      'email_not_allow_register'=>'email 不允许注册',
      'the_email_has_register'=>'该 email 已经被注册',
      'welcome_you_register'=>'欢迎您注册',
      'please_onclick_this_address_activate'=>'请点击此地址来激活您的登录账号：',
      'onclick_activate_account'=>'点击激账号',
);