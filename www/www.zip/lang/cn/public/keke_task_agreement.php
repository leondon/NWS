<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-2-13 下午12:04:26
*/
$lang=array(
       'you_has_agree_agreement_notice'=>'您已经同意了交付协议,无需再次签署',
       'agreement_signed_complete_wait_you'=>'协议签署完成,等待雇主签署协议',
       'agreement_signed_complete_to_deliver'=>'雇佣双方协议签署完成。进入交付阶段',
       'agreement_signed_fail'=>'协议签署失败',
       'you_has_agree_not_sign'=>'您已经同意了交付协议,无需再次签署',
       'agreement_signed_complete_wait_witkey'=>'协议签署完成,等待卖家(威客)签署协议',
       'agreement_link'=>'协议链接',
       'agreement_status'=>'协议状态',
       'deliver_agreement_sign'=>'交付协议签署',
       'agreement_complete_no_confirm_again'=>'当前协议已经签署完毕,无需再次确认',
       'warning_you_no_rights_submit'=>'警告,您无权提交源文件。',
       'seller_has_submit_wait_buyrer'=>'卖家已提交源文件、等待买家确认',
       'the_initiator'=>'发起者',
       'has_submit_source_files'=>'提交了源文件',
       'agreement_files_submit'=>'协议文件提交',
       'source_file_success'=>'源文件提交成功',
       'source_file_fail'=>'源文件提交失败',
       'warning_you_no_rights_confirm'=>'警告,您无权确认源文件提交。',
       'guarantee_pay_success'=>'担保付款成功',
       'guarantee_pay_fail'=>'担保付款失败',
       'buyer_has_confirm_deliver_complete'=>'买家已确认接收源文件,交付完成',
       'confirm_has_received_file'=>'确认接收了文件',
       'agreement_file_recevie'=>'协议文件接收',
       'source_file_confirm_deliver_success'=>'源文件确认完成，任务交付成功!',
       'file_confirm_fail_deliver_fail'=>'源文件确认失败，任务交付失败!',
       'current_status_can_not_confirm'=>'协议当前状态无法确认附件',
       'wait_sign'=>'待双方签署',
       'agreement_sign_complete'=>'协议签署完成',
       'task_order_complete'=>'任务交易完成'
);