<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-2-11 下午03:33:58
*/
$lang=array(
      'male'=>'男',
      'female'=>'女',
);