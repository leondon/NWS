<?php
$lang = array(
	'goods_order_confirm_pay'=>'商品订单确认付款',
	'stop_your_order_and_your_cash_return'=>'终止了您的订单(相关商品已被下架),您托管的赏金已被退回',
);