<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-2-13 上午11:37:46
*/
$lang=array(
       'seller_not_to_order_page'=>'卖家无法进入下单页面',
       'you_has_buy_work'=>'您购买过此作品、无需重复购买',
       'your_order_not_process_complete'=>'您关于此商品的订单还未处理完成',
       'seller_can_not_order_self'=>'卖家无法对自己的商品下单',
       'order_pay_fail_for_cash_little'=>'您的余额不足以支付此订单',
       'work'=>'作品',
       'service'=>'服务',
       'buy_goods'=>'购买商品',
       'user_action'=>'用户动作',
       'order_buy'=>'下单购买',
       'service_name'=>'服务名称',
       'service_type'=>'服务类型',
       'you_has_new'=>'您有新的',
       'order'=>'订单',
       'buy'=>'购买',
       'order_produce_success'=>'订单产生成功',
       'order_produce_fail'=>'订单产生失败',
       'can_not_to_self'=>'无法对自己发起',
);