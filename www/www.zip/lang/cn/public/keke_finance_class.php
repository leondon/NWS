<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-2-13 上午10:50:23
*/
$lang=array(
       'uid_parameter_no_value'=>'UID 参数没有值',
	   'release'=>'发布',
	   'task'=>'任务',
	   'extension_task'=>'延期任务',
	   'purchase_service_goods'=>'购买服务或商品',
	   'purchase'=>'购买',
	   'value_add_services'=>'增值服务',
	   'managed'=>'托管',
	   'bounty'=>'赏金',
	   'failure_refund'=>'失败退款',
	   'earnest_money'=>'诚意金',
	   'involved_task'=>'参与任务',
	   'manuscript_selected_success'=>'稿件被选为中标稿件',
	   'automate_return_remain'=>'自动选稿剩余金额返还',
	   'sell_services_goods'=>'卖出服务或商品',
	   'income'=>'所得',
	   'settlement_balance_return'=>'结算后余款返还',
	   'managed_balance_return'=>'托管余款返还',
	   'order'=>'订单',
	   'terminate_rebate'=>'终止返款',
	   'managed_commission_refund'=>'托管佣金返还',
	   'managed_commission_allocate'=>'托管佣金分配',
	   'user'=>'的用户',
	   'account'=>'账户为',
	   'to_cash'=>'提现',
	   'cash_failed_return_refund'=>'提现失败返还退款',
);