<?php
$lang = array(
	'from_task_over'=>'距任务结束',
	'task_hand_working_and_can_hand'=>'任务投稿进行中、欢迎交稿',
	'pity_click_task_can_hand_work_once'=>'很遗憾，点击任务单人只可交稿一次',
	'pity_hand_work_fail'=>'很遗憾，交稿失败',
	'task_fail_notice'=>'任务失败通知',
	'task_remain_cash_return'=>'任务余款返还通知',
	'task_over_notice'=>'任务结束通知',
	'over'=>'结束',
	'work_cash_js_notice'=>'稿件佣金结算通知',
);