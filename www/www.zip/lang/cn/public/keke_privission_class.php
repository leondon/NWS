<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-2-13 上午11:05:18
*/
$lang=array(
      'need_pass'=>'需要通过：',
      'user_not_login'=>'用户未登陆。',
      'in_24_hours'=>'24小时内',
      'times_no_more_than'=>'次数不得超过',
      'the_current_operate_forbidden'=>'当前操作被禁止',
      'you_current_is'=>'您当前是:',
      'level'=>'级',
      'employer_is_not'=>'雇主不受',
      'limit'=>'限制',
      'admin_customer_service_no_limit'=>'管理员、客服不受限制',
      'current_user_not_login'=>'当前用户未登陆',
);