<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-2-13 下午05:22:52
*/
$lang=array(
       'tender_notice'=>'招标通知',
       'you_pub_tender_task'=>'您发布的招标任务:',
       'has_choose_tender_please_choose'=>',已进入选标期，请尽快选标',
       'tender_fail'=>'招标失败',
       'submit_tender_no_witkey_fail'=>',投标期没有威客投标',
       'choose_tender_no_choose_fail'=>',选标期没有选标',
       'has_success_end'=>',已圆满结束',
		'ptzb'=>'普通招标',
		'tb'=>'投标',
		'xb'=>'选标',
);