<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-2-11 上午10:10:19
*/
$lang=array(
      'you_not_login'=>'您还未登陆',
      'unlock_fail'=>'解锁失败',
      'wrong_times_much_login_again'=>'错误次数过多，请重新登录',
      'shortcuts_add_success'=>'快捷方式添加成功',
      'shortcuts_add_fail'=>'快捷方式添加失败',
      'the_shortcuts_has_exist'=>'该快捷方式已存在',
      'not_delete_others_shortcuts'=>'无法删除他人快捷方式',
      'shortcuts_delete_success'=>'快捷方式删除成功',
      'shortcuts_delete_fail'=>'快捷方式删除失败',
      'please_choose_shortcut_menu'=>'请选择要操作的快捷菜单',
      'username_input_error'=>'用户名输入错误!',
      'username_password_input_error'=>'用户名或密码输入错误!',
      'login_fail'=>'登录失败!',
      'no_rights_login_backstage'=>'无权登录后台!',
      'login_system'=>'登陆系统',
      'login_success'=>'登录成功!'
);