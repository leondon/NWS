<?php
$lang = array(
	'please_son_industry'=>'请选择子行业',
	'hand_work_timeout'=>'投稿结束时间',
	'choose_timeout'=>'选稿结束时间',
	'pub_task_notice'=>'任务发布提示',
	'use_payitem_service'=>'使用增值服务:',
	'you_not_choose_task_model'=>'您没有选择任务模式,无法进入此页面',
	'you_not_choose_task_model_and_not_in'=>'您没有选择任务模式,无法进入此页面',
	'you_not_fill_requirement_and_not_in'=>'您没有填写任务需求,无法进入此页面',
	'the_page_timeout_notice'=>'此页面已过期,无法进入此页面,现在跳往发布页面',
	'can_pub'=>'可以发布',
	'not_rights_pub_task'=>'您没有发布权限。',
	'key_information_missed'=>'任务关键信息缺失，发布失败，请重新发布或联系客服',
	'task_cash_negatvie'=>'任务金额为负数',

);