<?php
$lang = array(
	

);