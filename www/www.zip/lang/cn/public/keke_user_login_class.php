<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-2-11 下午03:07:14
*/
$lang=array(
      'password_input_error'=>'密码输入错误',
      'account_has_freeze_or_unactivate'=>'帐户已经冻结,或者没有激活',
      'no_tel_auth_not_login'=>'您没有通过手机认证，无法用手机号登录',
      'no_email_auth_not_login'=>'您的没有通过邮箱认证，无法用邮箱登录',
	  'integrated_model_nust_use_name'=>'整合模式只能使用用户名登陆',
      'you_input_username_error'=>'您输入的用户名不正确',
      'you_input_password_not_right'=>'您输入的密码不正确',
      'you_input_username_not_exist'=>'您输入的用户名不存在',
	  'you_input_username_or_password_not_exist'=>'您输入的用户名或密码有误',
      'notice_message'=>'提示信息',
      'login_success'=>'登录成功!',
	  'account_has_not_excited'=>'用户账户暂未激活,请尽快登陆邮箱激活账户',
		'freezed'=>'您的密码已输错5次，为了保护您的账号安全，此账户已被冻结。',
		'before'=>'你还有',
		'willfreezed'	=>'次机会，密码输入超过5次，账户将被冻结。'
);