<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-2-11 下午12:08:21
*/
$lang=array(
      'prom_fail'=>'推广失败',
	  'prom_success'=>'推广成功',
      'you_can_not_prom_self'=>'您无法推广自己',
      'your_prom_user_has_promer'=>'由于您推广的用户已经存在上线、无法再被您推广',
      'prom_system_closed'=>'由于推广系统已经关闭、您此次推广失败',
      'prom_msg_notice'=>'推广消息提示',
      'you_prom_offline'=>'您推广的下线',
      'complete_event_get_money_notice'=>'完成了相应事件，您获得了相应提成金，请前往推广中心查看具体内容',
      'event_fail_notice'=>'参与的相应事件失败，您获取推广金失败，请前往推广中心查看具体内容',
      'from_you_prom_website_user'=>'通过您的推广链接进入本站的用户',
      'already_exist_prom_promotion_fail'=>'已存在推广、您此次推广失败',
      'not_take_effect'=>'未生效',
      'has_task_effect'=>'已生效',
      'has_over_time'=>'已过期',
      'not_settlement'=>'未结算',
      'has_settlement'=>'已结算',
      'has_fail'=>'已失败',
	  'txyhm'=>'推广用户名',
	  'tx_sj'=>'事件',
	  'tx_je'=>'推广金额',
);