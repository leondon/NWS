<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-2-13 上午10:11:36
*/
$lang=array(
       'realname_auth'=>'实名认证',
	   'bank_auth'=>'银行认证',
	   'email_auth'=>'邮箱认证',
	   'enterprise_auth'=>'企业认证',
	   'mobile_auth'=>'手机认证',
	   'weibo_auth'=>'微博认证',
       'apply_not_exist_delete_fail'=>'申请不存在，删除失败',
       'apply_delete_success'=>'申请删除成功',
	   'apply_delete_fail'=>'申请删除失败',
       'apply_not_exist_audit_fail'=>'申请不存在，审核失败',
       'apply_pass'=>'申请通过',
       'has_pass'=>'已通过',
       'through'=>'通过',
       'has_pass_please_to'=>'已通过，请到',
       'view_detail'=>'查看详细',
       'apply_audit_success'=>'申请审核成功',
       'apply_not_pass'=>'申请不通过',
		'prom_auth_success'=>'推广认证成功',
       'not_pass_please_to'=>'不通过，请到',
       'apply_audit_not_pass'=>'申请审核不通过',
);