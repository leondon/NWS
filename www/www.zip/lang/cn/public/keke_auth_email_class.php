<?php
$lang = array (
	'apply_not_exist_nopass'=>'申请不存在，审核失败',
	'through'=>'通过',
	'news_notice'=>'消息提示',
	'email_auth'=>'邮箱认证',
	'__email_auth'=>'--邮箱认证',
	'please_click_email_auth_url'=>'请点击邮箱认证地址：',

);