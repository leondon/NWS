<?php
$lang = array(
/****/
	'be'=>'被',
	'delete_task'=>'删除任务',
	
);