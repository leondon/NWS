<?php
/**
 * 多人悬赏编辑页语言包
 * 数组键的定义:
 * 单词与单词之间必须用下划线来连接,首字母必须用小写，适用于所有的lang数组；
 * @version kppw2.0
 * @author S
 * @2011-12-22
 */
$lang = array(
//task_edit_htm

	'task_bidding_manage'=>'招标',
	'task_name'=>'任务名',
	'title_err'=>'错误的标题名',
	'username_3_12_characters'=>'用户名为3到12个字符',
	'whether_this_task'=>'是否推荐此任务',
	'img_upload'=>'图片上传',
	'attachment_task'=>'任务附件',
	'no_attachment'=>'暂无附件',
	'expiration_time'=>'到期时间',

//task_edit_php


	'must_select_a_industry'=>'必须选择一个行业',
	'edit_task'=>'编辑任务',
	'edit_your_tasks'=>'编辑了您的任务',
	'task_edit_success'=>'任务编辑成功',
	'task_edit_fail'=>'任务编辑失败',

);