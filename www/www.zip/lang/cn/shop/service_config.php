<?php
/**
 * 服务配置
 * @version kppw2.0
 * @author deng
 * 2011-12-26
 */
$lang = array(
/*service_config.php*/
      'update_success'=>'修改成功',
      'update_fail'=>'修改失败',
      'permissions_config_update_success'=>'权限配置修改成功',

/*service_config.htm*/
	  'counts'=>'个',
      'item_name'=>'项目名称',     
      'user_identity'=>'用户身份',
      'times_limit'=>'次数限制',
	  'witkey_service_config'=>'威客服务配置',
	  'service_trans_charge_rate'=>'服务交易收费比例',
	  'service_royalty_rate'=>'服务提成比例',
	  'please_input_service_royalty_rate'=>'请填写服务提成比例',
	  'website_royalty_rate_notice'=>'网站从服务中获取的抽成比例,0为不收费',
	  'service_submit_min_money'=>'服务发布最小金额',
	  'submit_min_money_can_null'=>'服务发布最小金额，如不限制可留空',
	  'please_input_min_submit_money'=>'请填写最小发布金额',
	  'zero_or_null_no_limit'=>'0或空为不限制',
	  'service_submit_audit_money'=>'服务发布审核金额',
	  'submit_audit_money_can_null'=>'服务发布审核金额，如不限制可留空',
	  'please_input_submit_audit_money'=>'请填写发布审核金额',
	  'service_each_stage_min_money'=>'服务每阶段最小金额',
	  'please_input_allow_min_money'=>'请填写每阶段允许最小金额',

);