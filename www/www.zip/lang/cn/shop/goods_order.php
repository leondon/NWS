<?php
/**
 * 作品订单
 * @version kppw2.0
 * @author deng
 * 2011-12-23
 */
$lang = array(
/*goods_order.php*/
	  'has_delete_order_name_is'=>'删除了订单名为',
      'of_witkey_goods_order'=>'的威客作品订单',
      'has_mulit_delete_witkey_goods'=>'批量删除了威客作品订单',


/*goods_order.htm*/
	'witkey_goods'=>'威客作品',
      'give_order_people'=>'下订单人',
      'please_choose_order_status'=>'请选择订单状态',
      'order_time'=>'订单时间',
      'order_list'=>'订单列表',
      'order_name'=>'订单名字',
      'order_money'=>'订单金额',
      'order_time'=>'下单时间',
      'number_detail'=>'号详情',

);