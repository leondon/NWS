<?php
/**
 * 
 * @version kppw2.0
 * @author deng
 * 2011-12-23
 */
$lang = array(
/*goods_config.php*/
      'goods_basic_config_update_success'=>'作品基本配置修改成功',
      'goods_flow_config_update_success'=>'作品流程配置修改成功',
      'goods_flow_config_update_fail'=>'作品流程配置修改失败',
      'goods_permissions_config_update_success'=>'作品权限配置修改成功',

/*goods_config.htm*/
	  'witkey_goods_config'=>'威客作品配置',
      'is_private_model'=>'是否为私有模型',
      'private_not_show_on_shop'=>'私有模型不会出现在商城的选择列表上',
      'audit_money'=>'审核金额',
      'goods_audit_money'=>'作品审核金额',
      'please_input_goods_aduita_money'=>'请填写作品审核金额',
      'money_less_this_need_audit'=>'0当作品发布时的金额小于这个数时，需要审核',
      'goods_min_deal_total_money'=>'作品最小成交总金额',
      'goods_min_deal_money'=>'作品最小成交金额',
      'please_input_min_deal_money'=>'请填写最小成交金额',
      'zero_is_no_limit'=>'0为不限制',
      'goods_royalty_rate'=>'作品提成比例',
      'fail_royalty_rate'=>'失败提成比例',
      'mark_default_day'=>'互评默认天数',
	  'service_attachment_number_limit'=>'服务附件数量限制',
	  'service_attachment_number_can_not_null'=>'附件数量为正整数1-20个,不可留空',
	  'please_input_allow_attachment_number'=>'请填写允许附件数量',
	  'counts'=>'个',
      'goods_royalty_rate_msg'=>'作品提成比例值为正整数，长度',
      'goods_royalty_rate_positive_integer'=>'作品提成比例值为正整数',
      'fail_royalty_rate_msg'=>'失败提成比例值为正整数，长度',
      'fail_royalty_rate_positive_integer'=>'失败提成比例值为正整数',
      'mark_default_day_msg'=>'互评默认天数为正整数，长度',
      'mark_default_day_positive_integer'=>'互评默认天数为正整数',
      'item_name'=>'项目名称',     
      'user_identity'=>'用户身份',
      'times_limit'=>'次数限制',

);