<?php
/**
 * 
 * @version kppw2.0
 * @author deng
 * 2011-12-26
 */
$lang = array(
/*service_process.htm*/

      'belong_to_service'=>'所属服务',
      'the_promoters'=>'发起人',
      'apply_status'=>'申请状态',
      'explain'=>'说明',
      'no_submit_attachment'=>'未提交附件',
      'process_scheme'=>'处理方案',
      'total_commission'=>'总佣金',
      'please_distribution_in_this_range'=>'请在这个范围内分配',
	  'reset_task'=>'重置任务',
	  'extension'=>'延长',
	  'set_extension_day_task_again'=>'设置延长天数后任务可以再次进行',
	  'cancel_bid'=>'取消中标',
	  'cancel_bid_user_not_again'=>'取消中标后此用户将无法再次中标',
	  'will_be'=>'将被',
      'of_goods_down'=>'的商品下架',
      'be'=>'被',
      'peopel_surplus'=>'人剩余',
      'deduction_be'=>'扣除被',
      'freeze_be'=>'冻结被',
      'untenable_reason'=>'不成立理由',
      'untenable'=>'不成立',
      'process'=>'处理',
//js
      'commission_not_support_negative'=>'填写错误，佣金分配不支持负数',
      'input_please_confirm'=>'填写错误，请确保',
      'commission_distribution_completely'=>'佣金分配完全',
      'distribution'=>'分配',
      'confirm_report'=>'确认提示',
      'your_current_process_scheme_is'=>'您当前的处理方案为',
      'warning_not_choose_process_scheme'=>'警告,你并没有选择处理方案',
      'warning_fill_in_deduction_point'=>'警告，请填写扣除点数',
      'waring_deduction_point_not_negative'=>'警告，扣除点数不支持负数',
      'waring_deduction'=>'警告，扣除',
      'max_is'=>'最大为',
      'waring_fill_in_freeze_day'=>'警告，请填写冻结天数',
      'will_user'=>'将用户',
      'of_goods'=>'的商品',
      'down'=>'下架',
      'deduction'=>'扣除',
      'freeze_user'=>'冻结用户',
      'untenable_reason_input_notice'=>'不成立理由不得少于20字,此内容将通知用户，请谨慎填写',
      'confirm_not_process'=>'确认不受理此',
      'record_reason_is'=>'记录,理由为'
);