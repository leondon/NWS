<?php
/**
 * 服务订单
 * @version kppw2.0
 * @author deng
 * 2011-12-26
 */
$lang = array(
/*service_order.php*/
	  'has_delete_order_name_is'=>'删除了订单名为',
	  'of_witkey_service_order'=>'的威客服务订单',
	  'has_mulit_delete_service_order'=>'批量删除了威客服务订单', 

/*service_order.htm*/
      'witkey_service'=>'威客服务',
      'service_list'=>'服务列表',
      'give_order_people'=>'下订单人',
      'please_choose_order_status'=>'请选择订单状态',
	  'not_pay'=>'未付款', 
	  'has_pay'=>'已付款',
	  'has_confirm_pay'=>'已确认付款', 
	  'pay_complete'=>'付款完成',
	  'service_complete'=>'服务完成',
	  'order_time'=>'下单时间',
      'order_list'=>'订单列表',
      'order_name'=>'订单名字',
      'order_money'=>'订单金额',
	  'service_status'=>'服务状态',


);