<?php
/**
 * 作品处理
 * @version kppw2.0
 * @author deng
 * 2011-12-23
 */
$lang = array(
/*goods_process.htm*/
   'order_manage'=>'订单管理',
	'work_list' =>'作品列表',
	'weike_work'=>'威客作品',
	'num'=>'好',
	'detail'=>'详情',
	'goods_order'=>'作品订单',
	'work_name'=>'威客作品',
	'buyer_name'=>'买家昵称',
	'require_num'=>'索要数量',
	'total'=>'小计',
	'no_detail'=>'暂无详情'
);