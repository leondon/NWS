<?php
/**
 * 作品服务
 * @version kppw2.0
 * @author deng
 * 2011-12-23
 */
$lang = array(
/*goods_list.php*/
      'wait_audit'=>'待审核',
      'to_witkey_goods_name_is'=>'对威客作品名为',
      'conduct'=>'进行',
      'goods_open_success'=>'作品启用成功',
      'goods_open_fail'=>'作品启用失败',
      'to_witkey_goods_conduct_mulit'=>'对威客作品进行批量',
      'mulit'=>'批量',
      'goods_disable_success'=>'作品禁用成功',
      'goods_disable_fail'=>'作品禁用失败',
/*goods_list.htm*/
		'witkey_goods'=>'威客作品',
      'goods_id'=>'作品编号',
		'result_show'=>'结果显示',
      'goods_status'=>'作品状态',
      'quotation_yuan_unit'=>'报价(元) / 单位',
      'location'=>'所在地',
      'confirm_pass_audit'=>'确认通过审核吗？',
      'confirm_open'=>'确认启用吗？',
		'batch_shelves'=>'批量上架',
		'batch_off_the_shelf'=>'批量下架',
		'shelves_this_product'=>'确定上架此商品吗',
		'merchandise_off_the_shelf'=>'确定将此商品下架吗',
		'shelves'=>'上架',
		'off_the_shelf'=>'下架',

);