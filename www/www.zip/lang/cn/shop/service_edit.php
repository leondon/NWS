<?php
/**
 * 服务编辑
 * @version kppw2.0
 * @author deng
 * 2011-12-26
 */
$lang = array(
/*service_edit.php*/
	  'to_witkey_service_name_is'=>'对威客服务名为',
	  'in_edit_operate'=>'进行编辑操作',
	  'service_edit_success'=>'服务编辑成功',
	  'service_edit_fail'=>'服务编辑失败',
		'service_name'=>'服务名称',
		'service_desc'=>'服务描述',

/*service_edit.htm*/
	'is_top'=>'是否推荐',
	  'witkey_service_list'=>'威客服务列表',
	  'title_not_null'=>'标题不得为空,5-50字',
	  'quotation_not_null'=>'报价不可以为空',
	  'quotation'=>'服务报价',
	  'quotation_ending_decimal_notice'=>'报价结尾小数点后保留2个0',
	  'goods_status'=>'服务状态',

);