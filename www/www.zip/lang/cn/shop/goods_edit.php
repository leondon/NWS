<?php
/**
 *威客作品编辑
 * @version kppw2.0
 * @author deng
 * 2011-12-23
 */
$lang = array(
/*goods_edit.php*/
	  'please_choose_should_edit_goods'=>'请选择要编辑的作品',
      'please_choose_son_industry'=>'请选择子行业',
      'to_witkey_goods_name_is'=>'对威客作品名为',
      'to_edit_operate'=>'进行编辑操作',
      'goods_edit_success'=>'作品编辑成功',
      'goods_edit_fail'=>'作品编辑失败',

/*goods_edit.htm*/
	'goods_desc'=>'商品描述',
	'is_top'=>'是否推荐',
		'goods_edit'=>'作品编辑',
		'witkey_goods'=>'威客作品编辑',
      'edit_witkey_goods'=>'编辑威客作品',
      'goods_name_is_not_null'=>'作品名称不能为空',
      'please_input_goods_name'=>'请输入作品名称',
      'goods_quotation'=>'作品报价',
      'goods_single_price_input_error'=>'作品单价填写错误',
      'goods_single_price_allow_decimal'=>'作品单价可以含小数',
      'goods_status'=>'作品状态',

);