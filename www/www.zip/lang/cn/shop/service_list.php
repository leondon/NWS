<?php
/**
 * 服务列表
 * @version kppw2.0
 * @author deng
 * 2011-12-26
 */
$lang = array(
/*service_list.php*/

	  'to_witkey_service_name_to'=>'对威客服务名为',
	  'in'=>'进行',
	  'service_disable_success'=>'服务禁用成功',
	  'service_disable_fail'=>'服务禁用失败',
      'service_audit_success'=>'服务审核成功',
	  'service_audit_fail'=>'服务审核失败',
	  'service_use_success'=>'服务启用成功',
	  'service_use_fail'=>'服务启用失败',
	  'to_witkey_service_has_in'=>'对威客服务进行了',
	  'mulit_use_success'=>'批量启用成功',
	  'mulit_use_fail'=>'批量启用失败',
	  'mulit_disable_success'=>'批量禁用成功',
	  'mulit_disable_fail'=>'批量禁用失败',
		'batch_shelves'=>'批量上架',
		'batch_off_the_shelf'=>'批量下架',
/*service_list.htm*/
      'witkey_service'=>'威客服务',
      'service_list'=>'服务列表',
	'service_name'=>'服务名称',
      'shop_list'=>'店铺列表',
      'goods_name'=>'商品名称',
      'goods_status'=>'商品状态',  
      'please_input_shop_name'=>'请输入店铺名称',
	  'shop_list'=>'店铺列表',
	  'quotation_yuan'=>'报价(元)',
	  'belong_to_industry'=>'所属行业',
	  'location'=>'所在地',
	  'detail'=>'详细',
	  'no_has'=>'无', 
      'confirm_pass_audit'=>'确认通过审核吗？',
      'confirm_use'=>'确认启用吗？',
      'shelves_this_product'=>'确定上架此商品吗',
      'merchandise_off_the_shelf'=>'确定将此商品下架吗',
      'shelves'=>'上架',
      'off_the_shelf'=>'下架',
);