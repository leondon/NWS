<?php
$lang = array(
      'delete_task'=>'删除任务',
      'freeze_task_success'=>'冻结任务成功',
      'freeze_task_fail'=>'冻结任务失败',
      'unfreeze_task_success'=>'任务解冻成功',
      'unfreeze_task_fail'=>'任务解冻失败',
      'task_recommend_success'=>'任务推荐成功',
      'task_recommend_fail'=>'任务推荐失败',
      'cancel_recommend_success'=>'取消推荐成功!',
      'cancel_recommend_fail'=>'取消推荐失败!',
      'recommended'=>'荐',
/***/
      'audit_success'=>'审核成功',
      'audit_not_pass'=>'审核不通过',
      'please_choose_task_status'=>'请选择任务状态',
      'overdue_time'=>'过期时间',




);