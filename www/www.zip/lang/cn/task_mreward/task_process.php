<?php
/**
 *多人悬赏
 * @version kppw2.0
 * @author deng
 * 2011-12-23
 */
$lang = array(
/*task_process.php*/

      'operate_complete'=>'操作完成',


/*task_process.htm*/


      'the_promoters'=>'发起人',
      'apply_status'=>'申请状态',
      'explain'=>'说明',
      'no_submit_attachment'=>'未提交附件',
      'belong_to_task'=>'所属任务',
      'task_cost'=>'任务费用',
      'process_scheme'=>'处理方案',
      'reset_task_status_is_in'=>'重置任务状态为进行中',
      'task_delay_day'=>'任务延期天数',
      'cancel_bid'=>'取消中标',
      'cancel_bid_to_not_bid'=>'取消中标后此搞件将无法再次中标',
      'be_report_people_surplus'=>'被举报人剩余',
      'deduction_be_report_people'=>'扣除被举报人',
      'suggest_deduction_point_not_more'=>'建议扣除点数不超过',
      'freeze_user'=>'冻结用户',
      'please_explain_reason'=>'请说明理由',
      'please_input_untenable_reason'=>'请填写不成立理由',
      'process'=>'处理',      
      'deduction'=>'扣除',
      'untenable_reason'=>'不成立理由',
      'untenable'=>'不成立',
      'commission_not_support_negative'=>'填写错误，佣金分配不支持负数',
      'input_please_confirm'=>'填写错误，请确保',
      'commission_distribution_equal'=>'佣金分配等于',
      'employer_distribution'=>'雇主分配',
      'witkey_distribution'=>'威客分配',
      'confirm_report'=>'确认提示',
      'your_current_process_scheme_is'=>'您当前的处理方案为',
      'warning_not_choose_process_scheme'=>'警告,你并没有选择处理方案',
      'please_input_delay_day'=>'请填写延期天数',
      'warning_fill_in_deduction_point'=>'警告，请填写扣除点数',
      'waring_deduction_point_not_negative'=>'警告，扣除点数不支持负数',
      'waring_deduction'=>'警告，扣除',
      'max_is'=>'最大为',
      'waring_fill_in_freeze_day'=>'警告，请填写冻结天数',
      'cancel_user'=>'取消用户',
      'of_bid_status'=>'的中标状态',
      'not_process_reason_not_null'=>'不受理，理由不能为空!',
      'confirm_not_process'=>'确认不受理此',
      'record_reason_is'=>'记录,理由为'
);