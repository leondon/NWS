<?php
/**
 * 后台多人悬赏列表
 * @version kppw2.0
 * @author deng
 * 2011-12-23
 */
$lang = array(
/*task_list.php*/
      'task_link'=>'任务链接',
      'website_name'=>'网站名称',


/*task_list.htm*/

      'task_cach'=>'任务金额(元)',


);