<?php
/**
 * @version kppw2.0
 * @author S
 * @2011-12-13
 */
 $lang = array(
/* admin_config_nav_htm */

     'nav_menu'=>'自定义导航',
	 'link'=>'链接',
	 'style'=>'样式',
	 'open_new_window'=>'新窗口打开',
 	 'menu'=>'菜单',
 	 'nav_mange'=>'导航管理',
 	 'nav'=>'导航',
 	 'sys_menu'=>'系统菜单',
 	 'menu_desc'=>'菜单的描述，如任务大厅',
 	 'link_before_desc'=>'如果是站内链接格式:index.php?do=task,task为下面要填写的样式;',
 	 'link_after_desc'=>'外站链接格式:http://www.baidu.com,下面样式为空即可',
	 'display_mode'=>'显示模式',
	 'show_all'=>'全部显示',
	 'hide_all'=>'全部隐藏',
     'hide_home'=>'首页隐藏',
	 'hide_mall'=>'商城隐藏',
	 'add_link'=>'增加链接',

/* admin_config_nav_php */
	 'create_nav'=>'创建导航',
 	 'edit_nav'=>'编辑导航',
 	 'delete_nav_success'=>'删除导航成功',
	 'custom_nav_set_success'=>'自定义导航设置成功',
 	'default_index'=>'默认首页',
 	'set_index'=>'设为首页',
 	'show_model'=>'显示模式',
 	'is_show'=>'显示',
 	'is_hide'=>'隐藏',
 	'set_index_success'=>'设置首页成功',
     'no_change'=>'没有任何修改',
); 