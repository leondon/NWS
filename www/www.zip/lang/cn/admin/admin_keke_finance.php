<?php

$lang = array(
	'period_query_record'=>'指定阶段查询财务记录',
	'this_week'=>'本周',
	'this_month'=>'本月',
	'half_year'=>'半年',
	'a_year'=>'一年',
	'cash_yuan'=>'金额(元)',
	'get_type'=>'获取方式',
	'task_name'=>'任务名称',
	'query_time'=>'查询时间',
	'expenditure_pattern'=>'支出方式',
	'task_time'=>'任务时间',
	'api_not_approved_unable'=>'您的联盟API没有申请或暂未通过审核，暂时无法使用此功能。',
	'prom_in'=>'推广收入',
	'prom_out'=>'推广支出',
	'in'=>'收入',
	'out'=>'支出',
	'task_bid'=>'任务中标',


);