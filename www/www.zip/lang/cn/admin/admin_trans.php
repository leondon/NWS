<?php
/**
 * @维权
 * @author deng
 * @2011-12-14 下午01:40:32
 * @charset:GBK
 * @version KPPW 2.0
 */
$lang=array(
      'record_delete_success'=>'记录删除成功',
      'record_delete_fail'=>'记录删除失败',
      'choose_delete_operate'=>'请选择要删除的操作项',
      'record_mulit_delete_success'=>'记录批量删除成功'
);
