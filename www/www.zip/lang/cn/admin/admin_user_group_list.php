<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2011-12-29 上午10:28:36
*/
$lang=array(
/*admin_user_group_list.php*/     
      'delete_user_group'=>'删除用户组',

/*admin_user_group_list.htm*/
      'system_group_manage'=>'系统组管理',
      'user_group_manage'=>'用户组管理',
      'add_user_group'=>'添加用户组',
      'user_group_list'=>'用户组列表',
      'group_name'=>'组名',
      'update_time'=>'更新时间',
);
 