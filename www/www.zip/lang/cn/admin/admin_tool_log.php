<?php
/**
*系统日志
*@author deng
*@version KPPW 2.0
*@charset:GBK
*2011-12-15 下午01:50:35
*/
$lang=array(
/*admin_tool_log.php */
      'empty_system_log_success'=>'清空系统日志成功',
      'empty_system_log'=>'清空系统日志成功',
		'delete_sys_log'=>'删除系统日志',
		'mulit_delete_log'=>'批量删除日志',
/*admin_tool_log.htm*/      
      'log'=>'日志',
      'operator'=>'操作员',
      'log_time'=>'日志时间',
      'warm_prompt'=>'温馨提示：请慎重操作',
      'user_groups'=>'用户组',
      'confirm_to_empty_all_logs'=>'确认清空所有日志吗?',
      'empty_log'=>'清空日志',
      'log_content'=>'日志内容',
);