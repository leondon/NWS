<?php 
/*广告组编辑页的语言包
 * @copyright keke-tach
 * @author S
 * @version kppw 2.0
 * @2011-12-27
 */
$lang = array(
//admin_tpl_ad_group_add_htm
	
	'ads_group'=>'广告组',
	'ads_group_manage'=>'广告组管理',
	'ads_group_tags'=>'广告组标签',
	'tags_name'=>'标签名称',
	'tpl_select'=>'模板选择',
	'tags_code'=>'标签代码',
	'cache_time'=>'缓存时间',
	'tigs_name_notice'=>'广告组标签名称，定义是多个单广告名称相同的广告可以组成一个广告组',
	'model_tigs_select'=>'选择需要加载的模板*必填',
	'tigs_code'=>'广告组标签代码为模板代码，可用的变量为',
	'blank_not_cache'=>'秒为单位,留空为不缓存',

	'ads_name'=>'广告位名称',
	'ads_description'=>'广告位描述',
	'ads_has_been_under'=>'该广告位下已经有',
	'ads_allow'=>'条广告/广告允许',
	'ads_title_not_empty'=>'广告标题不可为空',
	'set_ads_start_info'=>'设置广告起始生效的时间，留空为不限制起始时间',
	'set_ads_end_info'=>'设置广告广告结束的时间，留空为不限制结束时间',
	'select_tpl'=>'可选模板',
	'ads_thumbnail'=>'广告缩略图',

//admin_tpl_ad_group_add_php

	'ads_group_edit'=>'广告组编辑',
	'ads_group_add'=>'广告组添加',
	'success'=>'成功!',
	'fail'=>'失败!',
	'edit_parameter_error'=>'编辑参数错误',
	'jump_to_advertisement_page'=>'跳转至广告添加页面',
	'before_jump_to_page'=>'跳转至之前页面',
	'loadcount'=>'调用数量',
	'count_you_wish'=>'您希望调用的广告数量',

);