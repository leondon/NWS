<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2011-12-29 上午10:40:29
*/
$lang=array(
/*admin_user_list.php*/
      'delete_member'=>'删除用户',
      'website_name'=>'网站名称',
      'user_freeze'=>'用户冻结',
      'unfreeze_member'=>'解冻用户',
      'delete_user'=>'删除用户',
      'mulit_delete_operate_success'=>'批量删除操作成功',
      'mulit_disable_operate_success'=>'批量禁用操作成功',
      'freeze_user'=>'冻结用户',
      'mulit_open_operate_success'=>'批量启用操作成功',
      'user_open'=>'用户开启',

/*admin_user_list.htm*/
      'member_manage'=>'用户管理',
      'add_member'=>'添加用户',
      'creat_time'=>'创建时间',
      'normal'=>'正常',
      'user_list'=>'用户列表',
      'user_group'=>'用户组',
      'user_status'=>'用户状态',
      'register_time'=>'注册时间',
	  'user_uid'=>'用户UID',
      'cash_coupon'=>'代金券',
      'balance'=>'余额',
      'set'=>'设置',
      'rights_set'=>'权限设置',
      'open_user_integration_confirm_notice'=>'您开启了用户整合，该操作会同时删除您在其它应用中的数据，确认？',
      'add_new_user'=>'添加新用户',
      'normal'=>'普通',
	  'recommend'=>'推荐',
	  'move_recommend'=>'取消推荐',
	  'sure_to_recommend'=>'确定推荐此用户吗?推荐后将在首页商城模块展示',
	  'sure_to_move_recommend'=>'确定取消推荐此用户吗?推荐后将取消在首页模块的展示',
);