<?php
/**
 * @添加技能
 * @author deng
 * @2011-12-13-下午05:17:13
 * @charset:GBK
 * @version KPPW 2.0
 */
$lang=array(
/*admin_task_skill_edit.htm*/
		'skill_list'=>'技能列表',
		'add_skill' => '技能添加',
      'edit_skill'=>'技能编辑',
      'choose_industry_class'=>'请选择行业分类',
      'you_choose_which_industry'=>'你准备哪类的行业呢？',
      'write_skill_name'=>'请填写技能名称!',
      'write_skill_order'=>'请填写技能排序!',
      'quick_skill_order'=>'快给技能排序吧!',
		'skill_has'=>'该技能已存在'
);