<?php
/**
* 后台锁屏
*@author deng
*@version KPPW 2.0
*2011-12-26 下午04:15:50
*/
$lang=array(
/*admin_screen_lock.htm*/
      'password_can_not_null'=>'密码不能为空',
      'please_input_right_password_unlock'=>'请填写正确密码解锁',
      'you_have'=>'您还有',
      'times_try_chance'=>'次尝试机会!'

);