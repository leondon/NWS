<?php
/**
 * @行业管理
 * @author deng
 * @2011-12-13-下午04:21:32
 * @charset:GBK
 * @version KPPW 2.0
 */
$lang=array(
/*admin_task_industry.htm */
	  'industry_merge'=>'行业合并',
      'by_industry'=>'所属行业',
      'support_fuzzy_query'=>'(行业的子类)',
	  'edit_industry'=>'编辑了行业',
	  'delete_industry'=>'删除了行业',
      'add_time'=>'添加时间',
      'show_order'=>'显示顺序',
      'change_time'=>'修改时间',
      'add_son_class'=>'增加子类',
	  'indus_parent'=>'(行业的父类)'
);