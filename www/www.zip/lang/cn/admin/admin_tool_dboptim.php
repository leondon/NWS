<?php
/**
*数据库恢复
*@author deng
*@version KPPW 2.0
*@charset:GBK
*2011-12-15 下午02:29:50
*/
$lang=array(
/*admin_tool_dboptim.php*/
      'no_select_table'=>'没要选择要优化的表',
 
/*admin_tool_dboptim.htm*/
      
	  'db_optim'=>'数据库优化',
	  'db_table'=>'数据表',
	  'chip'=>' 碎片',	
	  'no_optimizations'=>'暂无可优化表',
	  'db_repair'=>'数据库修复',
	  'db_table'=>'数据表',
	  'start'=>' 开始',	
	  'no_optimizations'=>'暂无可修复表',
	  'repair_tip1'=>'请勿过于频繁的进行数据库修复操作，请在您的数据库出现致命错误时进行操作，例如：.MYI索引文件缺失；',
	  'repair_tip2'=>'如果在修复过程中，服务器停机，则在重新启动之后，在执行其它操作之前，请您尽量先对表再执行一此修复。',
);