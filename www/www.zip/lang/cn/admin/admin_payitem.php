<?php
/**
 * @增值服务的安装，uninstall,查询，删除
 * @author deng
 * @2011-12-14 下午02:30:21
 * @charset:GBK
 * @version KPPW 2.0
 */
$lang=array(
/*admin_payitem_index.php*/

      'month'=>'月',
      'year'=>'年',
		'install_new_add_manage'=>'安装了新的增值服务管理',
      'payitem_close_success'=>'增值服务关闭成功',
      'payitem_close_fail'=>'增值服务关闭失败',
      'payitem_open_success'=>'增值服务开启成功',
      'payitem_open_fail'=>'增值服务开启失败',
      'payitem_uninstall_success'=>'增值服务卸载成功',
      'payitem_uninstall_fail'=>'增值服务卸载失败',
      'payitem_install_success'=>'增值服务安装成功',
      'payitem_install_fail'=>'增值服务安装失败',


/*admin_payitem_index.htm*/
      'payitem_manage'=>'增值服务管理',
      'serve_id'=>'服务id',
      'use_status'=>'启用状态',
      'serve_name'=>'服务名称',
      'serve_icon'=>'服务图标',
      'serve_cost'=>'服务费用',
      'user_type'=>'用户类型',
      'comfirm_to_uninstall_model'=>'确定要卸载此任务模型吗？',
      'install_payitem_input_contents'=>'安装新增值服务 , 请输入所在目录'
);