<?php
/**
 * @copyright keke-tech
 * @author S
 * @version v 2.0
 * 2011-12-15
 */
$lang = array(
//admin_tpl_edit_link_htm

    'links'=>'友情链接',
	'link_manage'=>'链接管理',
	'link_set'=>'链接设置',
	'link'=>'链接',
	'links_type'=>'友情链接类型',
	'home_show'=>'首页显示',
	'home_pages'=>'首页内页显示',
	'links_name'=>'友情链接名称',
	'links_name_not_exists'=>'友情链接名称不能为空，长度限制在1-50',
	'links_url'=>'友情链接地址',
	'links_url_not_exists'=>'友情链接地址不能为空，长度限制在3-100',
    'links_img_url'=>'友情链接图片地址',
//admin_tpl_edit_link_php	
	
	'links_edit'=>'编辑友情链接',
	'links_add'=>'添加友情链接',
	'links_edit_success'=>'友情链接编辑成功',
//admin_tpl_link_htm	
	
	'link_add'=>'链接添加',
    'link_id'=>'链接ID',
	'default_id_sort'=>'默认id排序',
	'link_ids'=>'链接名',
	'tag_list'=>'标签列表',
	'link_type'=>'链接类型',
    'link_name'=>'链接名称',
	'link_url'=>'链接地址',
	'link_home'=>'首页链接',
	'link_page'=>'内页链接',
	'link_home_page'=>'首页内页链接',
	'comfirm_delete_select'=>'确定删除所选？',
//admin_tpl_link_php	
	
	'links_delete'=>'删除友情链接',	
	'links_delete_success'=>'友情链接删除成功',
	'links_not_exists'=>'友情链接不存在，删除失败',
);
	