<?php
/**
 * 信息配置
 * @author hr
 * @version kppw2.0
 * 2011-12-13  下午03:25:28
 */

	$lang = array(
	
			/* admin_msg_config.php */
		'edit_mobile_log'=>'编辑手机平台',
		'binding_cellphone_account_successfully' => '手机账号绑定成功',
		'binding_cellphone_account_fail' => '手机账号绑定失败',
		'get_user_info_fail' => '用户信息获取失败',
		'not_bind_cellphone_account' => '您还没有绑定手机账号',
	
			/* admin_msg_config.htm */
	
		'msg_tpl_page_title' => '短信账号管理',
		'change_account' => '账号变更',
		'send_sms' => '短信发送',
		'sms_config' => '账号管理',
		'apply_for_account' => '申请账号',
		'click_to_apply_account' => '点击申请账号',
		'sms_account' => '短信账号',
		'account_cannot_be_null' => '输入账号不能为空',
		'input_cellphone_validate_code' => '请输入你获取的手机短信账号',
		'sms_password' => '短信密码',
		'password_cannot_be_null' => '输入密码不能为空',
		'input_cellphone_password' => '请输入你获取的手机短信密码',
		'account_info' => '账号信息',
		'balance_inquiries' => '余额查询',
		'user_recharge' => '用户充值',
		'account_change'=>'账号变更',
		'available_num' => '可用条数',
	);