<?php
$lang = array(

	'has_acquired_task'=>'已获取任务',
	'promotion_expenses'=>'推广费用',
	'asc'=>'以上',
	'desc'=>'以下',
	'server_industry_list'=>'服务器上的行业列表',
	'time_limit'=>'时间限制',
	'post'=>'发布于',
	'after'=>'之后',
	'prior'=>'之前',
	'left'=>'还剩',
	'day_end'=>'天结束',
	'task_id'=>'任务id',
	'class'=>'分类',
	'money'=>'金额',
	'promotion_fee'=>'推广费',
	'source'=>'来源',
	'surplus'=>'剩余',
	'web_development'=>'网站开发',
	'test_task'=>'测试任务',
	'in'=>'进行中',
	'brain_with_network'=>'脑跟网',
	'3_day_10_hour'=>'3天10小时',
	'promotion_marketing'=>'推广营销',
	'wibo_marketing_task'=>'微博营销任务 1个500元',
	'distributed'=>'待分配',
	'universal_network'=>'万能网',
	'mulit_get'=>'批量获取',




);