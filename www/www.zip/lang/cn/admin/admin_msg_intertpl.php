<?php
/**
 * 短信模板
 * @author hr
 * @version kppw2.0
 * 2011-12-13  下午04:05:33
 */

		$lang = array(
			/* admin_msg_intertpl.php */
		'edit_sms_tpl' => '修改短信模板',
		'edit_sms_tpl_success' => '模板修改成功',
		'save_sms_tpl_success' => '模板保存成功',
		
			/* admin_msg_intertpl.htm */
		'admin_msg_intertpl_title' => '短信模板',
		'sms_config' => '模板列表',
		'sms_tpl_edit' => '模板编辑',
		'sms_email_config_manage' => '短信邮件模板配置管理',
		'type_of_sms_email' => '短信邮件类型',
		'select_tpl_type' => '请选择模板类型',
		'msg_tips' => '消息提示',
		'sms_email_content' => '短信邮件内容',
		'sms_content' => ' 手机短信内容',
		'null_result_please_retry_later' => '查询结果为空，请稍后再试...',
		'null_tpl_content' => '模板内容为空!',
		'select_tpl' => '请选择模板!'
		);