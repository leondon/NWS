<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-1-17 上午11:07:03
*/
$lang=array(
/*admin_finance_all.php*/
	'delete_financial_records'=>'删除财务记录',
	'list_finance_delete_success'=>'财务清单删除成功',
	'list_finance_delete_fail'=>'财务清单删除失败',
	'mulit_delete_financial_records'=>'批量删除财务记录',
	'mulit_operate_fail'=>'批量操作失败，请重新操作',

/*admin_finance_all.htm*/
	'financial_type'=>'财务类型',
	'financial_id'=>'财务编号',
	'financial_uses'=>'财务用途',
	'money'=>'金额',
	'user_balance'=>'用户余额',
	'cash_coupon'=>'代金券',
	'user_remaining_coupons'=>'用户剩余代金券',
	'clearing_time'=>'结算时间',
);
