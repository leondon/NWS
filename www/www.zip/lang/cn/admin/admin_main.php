<?php
/**
* 管理首页
*@author deng
*@version KPPW 2.0
*@charset:GBK
*2011-12-26 下午03:04:59
*/
$lang=array(
/*admin_main.htm*/
      'manage_index'=>'管理首页',
      'safe_report'=>'安全提示',
      'suggest_rename_notice'=>'强烈建议您将 keke目录重新命名,避免黑客扫描',
      'suggest_hide_notice'=>'强烈建议您使用 data目录隐藏功能，此功能可大大提高网站安全性，设置方法请参照相关帮助文档或联系官方寻求帮助',
      'good_morning'=>'上午好',
      'founder'=>'创始人',
      'today_is'=>'今天是',
      'you_have'=>'您有',
      'counts_message'=>'条留言',
      'new_member'=>'新增用户',
      'new_task'=>'新增任务',
      'withdraw_apply'=>'提现申请',
      'user_recharge'=>'用户充值',
      'user_message'=>'用户留言',
      'trans_rights'=>'交易维权',
      'system_announcement'=>'系统公告',
      'authorization_info'=>'授权信息',
      'Value_added_service'=>'增值服务',
      'version_number'=>'版 本 号',
      'auhorization_type'=>'授权类别',
      'authorization_code'=>'授 权 码',
      'server_info'=>'服务器信息',
      'server'=>'服务器',
      'server_software'=>'服务器软件',
      'site_physical_path'=>'站点物理路径',
      'support'=>'支持',
      'version'=>'版本',
	'db_size'=>'数据库大小 ',
	'upload_size'=>'上传文件大小',
      'server_max_upload_file'=>'最大上传文件',
      'today_statistics'=>'本日统计',
      'members_register'=>'用户注册',
      'task_release'=>'任务发布',
      'ad_leasing'=>'广告位招租',
);