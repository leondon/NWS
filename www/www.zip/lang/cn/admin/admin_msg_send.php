<?php
/**
 * 短信发送
 * @author hr
 * @version kppw2.0
 * 2011-12-13  下午04:16:54
 */

	$lang = array(
		/* admin_msg_send.php  */
		'he_came_from_mars' => '查无此人',//来自火星
		'no_record_of_his_cellphone' => '查询用户没有填写自己的手机号码',
		'msg_send_log'=>'短信发送',
		
		
		/* admin_msg_send.htm  */
		'interface_config_manage' => '短信账号管理',
		'change_account' => '账号管理',
		'send_sms' => '短信发送',
		'select_user_group' => '选择用户组别',
		'comm_user' => '普通用户',
		'vip_user' => 'VIP用户',
		'named_user' => '指定用户',
		'find_user' => '查找用户',
		'click_and_find' => '点击查询',
		'separated_by_commas' => '如需添加号码，请用逗号分隔。如：',
		'sms_content' => '短信内容',
		'tips_about_send_sms' => '非指定用户发送短消息时,将给该类下所有满足条件用户发送短信',
		'first_enter_username_or_ids' => '请先填写待查询用户名或ID',
		'at_least_two_words' => '短信信息不得少于2个字',
		'sms_send_success'=>'短信发送成功',
		'sms_send_fail'=>'短信发送失败'
	);