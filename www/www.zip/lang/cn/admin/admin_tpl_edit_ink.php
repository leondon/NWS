<?php
/**
 * this not free,powered by keke-tech
 * @author jiujiang
 * @charset:GBK  last-modify 2011-12-16-上午11:01:27
 * @version V2.0
 */
$lang = array(
//admin_tpl_edit_link_htm

'links'=>'友情链接',
'link_manage'=>'链接管理',
'link_set'=>'链接设置',
'link'=>'链接',
'remote_link'=>'远程链接',
'pic_upload'=>'图片上传',
'links_type'=>'友情链接类型',
'home_show'=>'首页显示',
'page_show'=>'内页显示',
'home_pages'=>'首页内页显示',
'links_name'=>'友情链接名称',
'links_name_not_exists'=>'友情链接名称不能为空，长度限制在1-50',
'links_url'=>'友情链接地址',
'links_url_not_exists'=>'友情链接地址不正确，长度限制在8-100',
'links_img_url'=>'友情链接图片地址',
'link_edit'=>'链接编辑',
'link_add'=>'链接添加',
//admin_tpl_edit_link_php

'links_edit'=>'编辑友情链接',
'links_add'=>'添加友情链接',
'links_edit_success'=>'友情链接编辑成功',);