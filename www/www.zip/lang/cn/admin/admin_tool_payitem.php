<?php

$lang=array(
/*admin_tool_payitem.htm*/      
      'choose_service_provide_latest_news'=>'当您选择了这项服务时，你就获得了以最快的方式向您的客户提供最新消息的方式。',
      'first_latest_changes_send_commsuer_details'=>'1. 当您的客户所发布的任务有最新的变动时，它便会将所发布任务的最新动向以短消息的方式发送到你的客户的手机上，以便的您的客户能在第一时间内获知详情。',
      'second_latest_news_vip_have_priority'=>'2. 当您的普通客户发布任务时，它也可以将最新的任务以短消息的方式发送到您的VIP客户的手机上，
                           以便VIP客户能优先享有解决任务的权利。',
      'third_money_get_paid_send_message'=>'3. 当您的客户因解决任务而获得相应的报酬到账时，它也会以短消息的方式通知您的客户。',
      'keke_and_alipay_open_green_channel '=>'客客携手支付宝财付通开通绿色通道，不定期开展业务活动支付宝开通悬赏担保交易。本系统已经开通。',
      'alipay_business_configuration'=>'通支付宝担保交易，请申请业务后在进行配置。',
      'taobao_buyers_preferred'=>'支付宝首创交易模式，淘宝广泛使用，买家收货确认后打款，安全有保障，买家首选。',
      'proxy_million_and_western_join_quickly'=>'客客族已全面代理万网和西部数据的空间、域名业务 优质的服务 稳定的空间 还不赶快参加 先到先得。',
);