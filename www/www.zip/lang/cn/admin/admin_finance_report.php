<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2012-1-17 上午10:34:38
*/
$lang=array(
/*admin_finance_in.php*/
	'years'=>'年',
	'annual_report'=>'年报',
	'month'=>'月',
	'monthly_report'=>'月报',
	'day_report'=>'日报',
	'finance'=>'财务',
	'table'=>'表',
	'financial_record_number'=>'财务记录数量',
	'gross_margin'=>'毛利',
	'export_excel'=>'导出Excel',
	'financial_statistics_derived'=>'财务统计导出',

/*admin_finance_in.htm*/
	'time_range'=>'时间范围',
	'report_mode'=>'报表模式',
	'day_report_table'=>'日报表',
	'monthly_report_table'=>'月报表',
	'years_report_table'=>'年报表',
	'flow_record_number'=>'流水记录数量',
	'recent_3_months'=>'最近3个月',
	'recent_half_year'=>'最近半年',
	'endtime_not_more_than_starttime'=>'结束时间不能大于开始时间',
/*admin_finance_report.php*/
    'generation_finance_report'=>'生成财务分析报表',
    'report_generation_success'=>'报表生成成功',
    'total'=>'总计',
    'witkey_task'=>'威客任务',
    'witkey_shop'=>'威客商城',
    'payitem_service'=>'增值服务',
    'user_auth'=>'用户认证',
/*admn_finance_report.htm*/
    'income_report'=>'收入报表',
    'refresh_report_data'=>'刷新报表数据',
    'all'=>'所有',
    'view'=>'查看',

);