<?php
/**
 * @copyright keke-tech
 * @author S
 * @version v 2.0
 * 2011-12-15
 */
$lang = array(
//admin_tpl_editfeed_php

    'add_fail_select_type'=>'添加标签失败,请选择feed类型!',
	'add_fail_alerady_exists'=>'添加标签失败,该标签已存在!',
//admin_tpl_editfeed_data_thm
	'dns_list'=>'动态列表',
	'feed_manage'=>'feed管理',
	'dns_manage'=>'动态管理',
	'tag_call'=>'标签调用',
    'dns_edit'=>'动态编辑',
	'dns_id'=>'动态ID',
	'dns_type'=>'动态类型',
	'dns_title'=>'动态标题',
	'return_list'=>'返回列表',
//admin_tpl_edirfeed_manage_htm	
	
	'tag_names'=>'标签名称',
	'feed_type'=>'feed类型',
    'select_type'=>'请选择类型',
	'feed_info'=>'feed类型,如提现,中标等',
	'read_number'=>'读取条数',
	'read_data_number'=>'读取的数据条数，不填默认为9条',
	'cache_name'=>'缓存名称',
	'cache_default_tag_name'=>'feed存放的缓存名称，不填默认为标签名称',
	'select_tpl'=>'模板选择',
    'tag_by_tpl'=>'标签所适用的网站模板',
	'tag_code'=>'标签代码',
	'data_list'=>'datalist为数据源',
	'on_time'=>'动态生成时间',
	'titile'=>'title为feed标题，',
	'cache_time'=>'缓存时间',
	'blank_not_cache'=>'秒为单位,留空为不缓存',
//admin_tpl_feed_php	
    'err_parameter'=>'错误的参数',
//admin_tpl_feed_data_htm

	'dns_call'=>'动态调用',
	'default_id_sort'=>'默认id排序',
	'dns_name'=>'动态名称',
	'dns_names'=>'动态名',
	'dns_list'=>'动态列表',
    'event_title'=>'事件标题',
	'event_type'=>'事件类型',
//admin_tpl_feed_manage_htm

    'tag_id'=>'标签ID',
	'dns_tag_list'=>'动态标签列表',
	'page_call_code'=>'内部调用代码',
	'js_call_code'=>'js调用代码',
	'preview'=>'预览',
	'create_tag'=>'创建标签',
    'comfirm_want_delete_select'=>'确定要删除所选?',
);