<?php
/**
 * 客服管理
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2011-12-29 上午09:53:10
*/
$lang=array(
/*admin_user_custom_add.php*/
      'the_user_not_exist'=>'该用户不存在',
      'set_user'=>'设置用户',
      'of_group'=>'的组',
      'user_group_set'=>'用户组设定',
      'set_your_backstage_user_group'=>'设置了您的后台用户组',
      'rights_set_success'=>'权限设置成功',

/*admin_user_custom_add.htm*/
      'rights_set'=>'用户组设置',
      'customer_service_manage'=>'用户组管理',
      'add_customer_service'=>'设置用户组',
      'set_rights'=>'设置用户组',
      'system_group'=>'系统组',
      'normal_member_group'=>'普通用户组',
      'normal_user'=>'普通用户',
      'rights'=>'权限',
      'no'=>'无',
      'user_group'=>'用户组',
      'please_input_right_phone'=>'请填写正确的电话，不填可留空',
      'please_input_right_email'=>'请填写正确的email，不填可留空',
      'format_error'=>'格式错误',
      'query'=>'查询',
);