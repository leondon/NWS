<?php
/**
*标签管理
*@author deng
*@version KPPW 2.0
*@charset:GBK
*2011-12-15 下午04:09:12
*/
$lang=array(
/*admin_tpl_taglist.htm*/
      'tag_manage'=>'标签管理',
      'tag_add'=>'标签添加',
      'template_type'=>'模板类型',
      'all_class'=>'所有类',
      'tag_name'=>'标签名称',
      'please_enter_tag_name'=>'请输入标签名称',
      'tag_name_error'=>'标签名称不正确',
      'default_id_order'=>'默认id排序',
      'template_name'=>'模板名',
      'tag_list'=>'标签列表',
      'internal_calling_code'=>'内部调用代码',
      'js_calling_code'=>'js调用代码',
      'preview'=>'预览',
      'detail'=>'详细',
      'comfirm_to_delete'=>'确定要删除?',
      'add_tag'=>'添加标签',
	  'tag_call'=>'标签调用',

/*admin_tpl_taglist.php*/
      'wrong_parameters'=>'错误的参数',
      'delete_tag'=>'删除了标签'
);