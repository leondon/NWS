<?php
/**
 * @添加行业
 * @author deng
 * @2011-12-13-下午03:31:42
 * @charset:GBK
 * @version KPPW 2.0
 */
$lang=array(
/*admin_task_industry_edit.htm*/
      'task_industry_class'=>'任务行业分类',
      'edit_industry'=>'编辑行业',
      'father_industry'=>'父行业',
      'choose_industry_class'=>'请选择行业分类',
      'you_choose_which_industry'=>'你准备哪类的行业呢？',
      'write_industry_name'=>'请填写行业名称!',
      'write_industry_order'=>'请填写行业排序!',
      'choose_class'=>'请选择分类',
      'class_has_choose'=>'分类已经选择',
      'indus_has'=>'该行业已存在'
);