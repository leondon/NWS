<?php
/**
 * @增值服务购买记录
 * @author deng
 * @2011-12-14 下午13:45:25
 * @charset:GBK
 * @version KPPW 2.0
 */
$lang=array(
/*admin_payitem_buy.php */
      'buy'=>'购买',
      'spend'=>'使用',

/*admin_payitem_buy.htm*/
      'buy_spend_payitem_record'=>'增值服务购买(使用)记录',
      'buy_or_spend_type'=>'购买/使用类型',
      'pay_item_type'=>'付费项类型',
      'spend_time'=>'使用时间',
      'buy_spend_list'=>'购买使用列表',
      'spend_type'=>'使用类型',
      'spend_cost'=>'使用花费',
      'spend_number'=>'使用数量',
      'user_buy_the_total_amount'=>'用户购买总金额',

);