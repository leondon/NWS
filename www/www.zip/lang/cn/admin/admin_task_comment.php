<?php
/**
 * @copyright keke-tech
 * @author S
 * @version kppw 2.0
 * 2011-12-14
 */
 $lang = array(
/* admin_task_comment_htm */

     'comfirm_want_delete'=>'确定要删除？',
     'task_communication'=>'任务交流',
	 'task_msg_list_page'=>'任务留言详细页',
     'task_comment_info'=>'任务留言详细页',
	 'task_name'=>'任务名称',
 	 'task_msg'=>'任务交留言',
	 'task_select_type'=>'请选择任务类型',
 	 'comment_time'=>'留言时间',
 	 'task_comment'=>'任务留言',
     'task_comment_list'=>'留言列表',
	 'reviewers'=>'评论者',
 	 'commenter'=>'评论者',
 /**admin_task_check_comment_htm **/
 	'task_miscellaneous'=>'任务杂项',	
	'view_tack_comment'=>'查看任务留言',
	'delete_task_comment'=>'任务留言删除',
	'confirm_delete_comment'=>'确认删除此条留言吗?',
);