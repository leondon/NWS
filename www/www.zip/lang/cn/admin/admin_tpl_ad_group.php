<?php 
/*
 * @copyright keke-tach
 * @author S
 * @version kppw 2.0
 * @2011-12-27
 */
$lang = array(
//admin_tpl_ad_group_htm

	'ads_manage'=>'广告管理',
	'advertising'=>'广告位',
	'ads_list'=>'广告列表',
	'ads_group'=>'广告组',
	'ads_group_manage'=>'广告组管理',
	'tpl_type'=>'模板类型',	
	'all_class'=>'所有类',
	'start_time_desc'=>'开始时间降序',
	'start_time_asc'=>'开始时间升序',
	'tags_name'=>'标签名',
	'internal_call_code'=>'内部调用代码',
	'js_code_call'=>'js调用代码',
	'preview'=>'预览',	
	'create_tags'=>'创建标签',
//admin_tpl_ad_group_php

	'delete_ads_tags_id'=>'删除广告标签id',
	'corresponding_ads_data'=>'对应的广告数据',
	'delete_ads_tags_success'=>'删除广告标签成功',
	'delete_fail_select_operation'=>'删除失败,请选择要操作的项',
	'mulit_delete_ads_tags'=>'批量删除广告标签',
	'is_corresponding_ads_data'=>'以及对应的广告数据',
	'mulit_delete_ads_tags_success'=>'批量删除广告标签成功',

);