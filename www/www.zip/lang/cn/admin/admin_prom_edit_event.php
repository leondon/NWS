<?php
/**
*
*@author deng
*@version KPPW 2.0
*2011-12-26 下午05:55:21
*/
$lang=array(


/*admin_prom_edit_event.htm*/
      'view_prom_event'=>'查看推广事件',
      'prom_finance_manage'=>'推广财务管理',
      'view_prom_event'=>'查看推广事件',
      'prom_event'=>'推广事件',
      'promoter'=>'推广人',
      'be_prom_people'=>'被推广人',
      'prom_income'=>'推广所得',
      'no_settlement'=>'暂未结算',
      'prom_time'=>'推广时间',
      'prom_descripton'=>'推广描述',
);
