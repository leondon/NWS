<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2011-12-29 上午10:11:00
*/
$lang=array(
/*admin_user_group_add.php*/
      'please_input_group_name'=>'请输入组名',
      'you_no_choose_rights'=>'您没有选择权限',
      'the_user_group_already_exists'=>'该用户组已存在',
      'edit_user_group'=>'编辑用户组',
      'creat_user_group'=>'创建用户组',

/*admin_user_group_add.htm*/
      'add_user_group'=>'添加用户组',
      'user_group_manage'=>'用户组管理',
      'group_name'=>'组名',
      'group_name_can_not_null'=>'组名不能为空',
      'please_input_right_group_name'=>'请输入正确的组名',
      'rights'=>'权限',
);