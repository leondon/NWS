<?php 
/*
 * @copyright keke-tach
 * @author S
 * @kppw 2.0
 * @2011-12-26
 */
 $lang = array(
//admin_tpl_ad_htm 
 
 	'ads_manage'=>'广告管理',
 	'advertising'=>'广告位',
 	'add'=>'添加',
 	'add_advertising'=>'广告位添加',
 	'ads_list'=>'广告列表',
  	'ads_group'=>'广告组',
 	'name_number'=>'名称/数量',
  	'maximum_number_of'=>'最大数量',
 	'sample_pictures'=>'示例图片',
 	'add_ads'=>'添加广告',
 	'ads_group_id'=>'广告位编号',
	'ads_group_name'=>'广告位名称',
	'ads_group_code'=>'广告位代码',
	'has_been_add_number'=>'已经添加数',
	'maximum_number'=>'最大数量',

 );