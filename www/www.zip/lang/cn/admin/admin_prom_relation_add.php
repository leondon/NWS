<?php
/**
*@author deng
*@version KPPW 2.0
*2011-12-26 下午03:54:49
*/
$lang=array(
/*admin_relation_info.php*/
      'edit_prom_relation_data'=>'编辑推广关系数据',
      'add_prom_relation'=>'添加推广关系(数据)',
      'creat_relation_success'=>'创建关系成功',
      'creat_relation_fail'=>'创建关系失败',


/*admin_relation_info.htm*/
      'relation'=>'关系',
      'relation_manage'=>'关系管理',
      'upline_user'=>'上线用户',
      'upline_username'=>'上线用户名',
      'downline'=>'下线',
      'downline_username'=>'下线用户名',
      'prom_type'=>'推广类型',
      'edit_relation'=>'编辑关系',
      'add_relation'=>'添加关系',
);