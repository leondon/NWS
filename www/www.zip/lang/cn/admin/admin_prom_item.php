<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2011-12-27 上午10:35:17
*/
$lang=array(
/*admin_prom_item.php*/
      'delete_prom_material'=>'删除推广素材',
      'delete_prom_material_success'=>'删除推广素材成功',
      'operate_fail_please_choose_again'=>'操作失败，请重新操作',
      'delete_fail_please_choose_operate'=>'删除失败,请选择操作项',
      'mulit_operate_fail_please_again'=>'批量操作失败，请重新操作',
      'mulit_delete_fail_please_choose'=>'批量删除失败,请选择操作项',

/*admin_prom_item.htm*/
      'prom_material_manage'=>'推广素材管理',
      'prom_material'=>'推广素材',
      'item_name'=>'项目名称',
      'item_type'=>'项目类型',
      'text'=>'文字',
      'on_time'=>'产生时间',
      'invited_register_manage'=>'邀请注册管理',
      'prom_name'=>'推广名称',
      'code_and_content'=>'代码与内容',
      'add_time'=>'添加时间',
      'add_prom_item'=>'添加推广项目',
);