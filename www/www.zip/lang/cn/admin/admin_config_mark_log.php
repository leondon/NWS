<?php
$lang=array(
    'to_be_evaluated'=>'待评',
	'manuscript'=>'稿件',
	//htm
	'mutual_evaluation_record_manage'=>'互评记录管理',
	'view_task'=>'查看任务',
	'view_shop'=>'查看商品',
	'mutual_evaluation_id'=>'互评ID',
	'from'=>'来自',
	'display_number'=>'显示条数',
	'mutual_evaluation_time'=>'互评时间',
	'mutual_evaluation_status'=>'互评状态',
	'mutual_evaluation_value'=>'互评值',
	'mutual_evaluation_record'=>'互评记录',
	'belong_model'=>'所属模型',
	'view_task'=>'查看任务',
	'view_service'=>'查看商品',
	'to_user'=>'对用户',
	'evaluation'=>'评价',
	'ability_credit'=>'能力/信誉值',
	'you_comfirm_want_to'=>'你确定要',

	);
	
 