<?php
/**
 * 技能合并
*@author deng
*@version KPPW 2.0
*2011-12-26 下午04:26:00
*/
$lang=array(
/*admin_task_union_industry.php*/
      'industry_union_success'=>'行业合并成功',
      'target_industry_not_top'=>'目标行业不能为顶级分类',

/*admin_task_union_industry.htm*/
      'industry_list'=>'行业列表',
      'industry_union'=>'行业合并',
      'choose_industry'=>'选择行业',
      'industry_will_be_save'=>'该行业是合并后的行业，将会被保留',
      'target_industry'=>'目标行业',
      'after_union_will_be_delete'=>'该行业是合并后将会自动被删除',
);