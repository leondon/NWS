<?php
/**
 * @version kppw2.0
 * @author S
 * @2011-12-13
 */
$lang = array(
/* admin_config_model_htm */
	'model_manage'=>'模型管理',
	'task_model_manage'=>'任务模型管理',
	'mall_model_manage'=>'商城模型管理',
	'model_id'=>'模型id',
	'enabled_status'=>'启用状态',
	'model_id'=>'模型标识',
	'model_name'=>'模型名',
	'model_dir'=>'模型目录',
	'model_author'=>'模型作者',
	'shop'=>'商城',
	'unloading_task_model'=>'确定要卸载此任务模型吗？',
	'install_new_model_dir'=>'安装新模型,请输入模板所在目录',

/* admin_config_model_php */
	'open_task_model'=>'开启任务模型',
	'close_task_model'=>'关闭任务模型',
	'create_task_model'=>'创建了任务模型',
	'delete_task_model'=>'删除任务模型',
	'edit_task_model'=>'编辑任务模型',
	'model_dir_not_exists'=>'操作失败,模型目录不存在',
	'model_cofing_not_exists'=>'操作失败,模型配置文件不存在',
	'model_id_already_exists'=>'操作失败,模型ID已存在',
	'model_add_success'=>'操作成功,模型添加成功',
	'model_unloading_success'=>'操作成功,模型卸载成功',	
	'install_file_not_exists'=>'安装文件不存在',
	);