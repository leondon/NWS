<?php
/**
*数据库恢复
*@author deng
*@version KPPW 2.0
*@charset:GBK
*2011-12-15 下午02:29:50
*/
$lang=array(
/*admin_tool_restore.php*/
      'restore_database_operate_success'=>'恢复数据库操作成功',
      'database_restore_success'=>'数据库还原成功',
      'restore_database_operate_fail'=>'恢复数据库操作失败',
      'database_restore_fail'=>'数据库还原失败',
      'delete_database_backup_file'=>'删除数据库备份文件',
      'delete_database_backup_file_success'=>'数据库备份文件删除成功',
      'delete_database_backup_file_fail'=>'数据库备份文件删除失败',


/*admin_tool_restore.htm*/
      'just_a_moment_restoring'=>'请稍侯,数据库正在还原中...',
      'database_name'=>' 数据库名',
      'restore'=>'还原',
      'comfirm_to_delete'=>'确定要删除？',
      'comfirm_to_restore_data'=>'确定要还原数据吗？请慎重操作。',
      'database_restore_tips'=>'数据库还原提示',
      'comfirm_to_upload_data_file'=>'确定要下载数据文件？'
);