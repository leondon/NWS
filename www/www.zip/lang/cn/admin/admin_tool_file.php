<?php
/**
*附件管理
*@author deng
*@version KPPW 2.0
*@charset:GBK
*2011-12-15 上午11:53:07
*/
$lang=array(
/*admin_tool_file.php*/
      'delete_attachment'=>'删除附件',
      'atachment_delete_success'=>'附件删除成功',
      'attchment_not_exist_delete_fail'=>'附件不存在，删除失败',


/*admin_tool_file.htm*/
      'attachment_name'=>'附件名称',
      'default_order_by_id'=>'默认ID排序',
      'upload_time'=>'上传时间',
      'belongs_task'=>'所属任务',
      'belongs_object'=>'所属对象',
      'comfirm_to_delete'=>'确定要删除？'
);