<?php
/**
 * @todo 充值审核
 * @author hr
 * @version kppw2.0
 * @encoding GBK
 * 2011-12-14 下午02:00:41
 */
  	
	$lang = array(
	
		/* admin_finance_recharge.php */
	'user_recharge_att_info'=>'用户打款附加信息',
	'confirm_cashin'=>'确认到账',
	'payment_has_been_success_no_need_repeat' => '该充值申请已经付款成功,无需重复确认',
	'recharge_single_num' => '充值单号',
	'recharge_cash' => '充值金额',
	'recharge_success' => '充值成功',
	'confirm_payment_recharge' => '确认充值订单',
	'message_about_recharge_success' => '充值订单确认成功',
	'recharge_fail' => '充值失败',
	'delete_apply_forwithdraw' => '删除提现申请',
	'message_about_delete' => '充值订单删除成功',
	'charge_num_not_exist' => '充值订单不存在，操作失败',
	'delete_recharge_order' => '删除充值订单',
	'charge_amount'=>'充值金额',
	'line_recharge_success'=>'线下充值成功',
	
		/* admin_finance_recharge.htm */
	'order_type' => '订单类型',
	'order_id_desc' => '单号递减',
	'order_id_asc' => '单号递增',
	'statistics_info' => '统计信息',
	'collection_type' => '收款类型',
	'recharge_er' => '充值人',
	'recharge_time' => '充值时间',
	'recharge_status' => '充值状态',
	'confirm_of_payment' => '确认付款',
	'user_does_not_charge_info'=>'用户并未填写充值信息',
	'mulit_delete_confirm_and_some_tips' => '你确定要批量删除,已付款的订单是无法删除的'
	);