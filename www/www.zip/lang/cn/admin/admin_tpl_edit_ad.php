<?php
/**
 * @copyright keke-tech
 * @author S
 * @version v 2.0
 * 2011-12-15
 */
$lang = array(
//admin_tpl_ad_php
    'ad_name'=>'广告名称',
    'delete_ad'=>'删除广告',
	'delete_ad_tag'=>'删除广告标签',
	'ad_delete_success'=>'广告删除成功',
	'ad_delete_fail'=>'广告删除失败',
	'ad_not_exists'=>'广告不存在，删除失败',
//admin_tpl_ad_group_htm

	'ad_manage'=>'广告管理',
	'a_ad_manage'=>'单广告管理',
	'ad_group_manage'=>'广告组管理',
	'tpl_type'=>'模板类型',
    'all_class'=>'所有类',
	'start_time_desc'=>'开始时间递减',
	'start_time_asc'=>'开始时间递增',
	'tag_name'=>'标签名',
	'internal_code'=>'内部调用代码',
    'js_calling_code'=>'js调用代码',
	'preview'=>'预览',
	'create_tag'=>'创建标签',
//admin_tpl_ad_one_htm	
	
	'ad_title'=>'广告标题',
	'ad_address'=>'广告地址',
    'calling_code'=>'调用代码',
	'add_ad'=>'添加广告',
//admin_tpl_edit_ad_php	
	
	'upload_file_exceeding'=>'上传的文件超过了php.ini里的最大限制',
	'edit_ad'=>'编辑广告',
	'edit_ad_success'=>'广告编辑成功',
    'edit_ad_group_success'=>'广告组编辑成功',
	'edit_ad_group_fail'=>'广告组编辑失败',
//admin_tpl_edit_ad_group_htm	
	
	'ad_group'=>'广告组',
	'ad_group_manage'=>'广告组管理',
	'tag_mode'=>'标签模式',
	'ad_group_tag'=>'广告组标签',
    'ad_group_name'=>'广告组名称',
	'ad_group_create_not_edit'=>'广告组名称创建后将无法修改',
	'select_tpl'=>'模板选择',
	'select_tag_tpl'=>'选择使用标签的模板',
	'tag_code'=>'标签代码',
	'datalist'=>'datalist为数据源',
	'ad_url'=>'ad_url为广告链接',
	'ad_content'=>'ad_content为广告描述',
	'ad_id'=>'ad_id为广告编号',
	'ad_file'=>'ad_file为广告文件路径',
	'cache_time'=>'缓存时间',
	'blank_not_cache'=>'秒为单位,留空为不缓存',
//admin_tpl_edit_ad_one_htm	
	
	'a_ad'=>'单广告',
	'ad_group_add_not_edit'=>'同广告组请用相同广告名.添加后无法更改',
	'ad_link_url'=>'广告链接地址',    
	'upload_file'=>'上传文件',
	'click_view'=>'点击查看',
	'ad_content'=>'广告内容',
	'text_ad_enter'=>'文字广告时填写',
 
 );