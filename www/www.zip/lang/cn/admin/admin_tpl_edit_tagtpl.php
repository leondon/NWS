<?php
/**
*编辑模板
*@author deng
*@version KPPW 2.0
*@charset:GBK
*2011-12-15 下午03:38:52
*/
$lang=array(
/*admin_tpl_edit_tagtpl.htm*/
      'edit_template'=>'编辑模板',
      'template_store_address'=>'模板存放地址',
      'template_code'=>'模板代码'
);