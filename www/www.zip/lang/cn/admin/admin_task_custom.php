<?php
/**
 * @copyright keke-tech
 * @author S
 * @version kppw 2.0
 * 2011-12-14
 */
$lang = array(
    /* admin_task_custom_repay_htm */
    'reply_title'=>'回复标题',
	'reply_title_not_empty'=>'回复标题不能为空',
	'enter_reply_title'=>'请填写回复标题',
	'reply_content'=>'回复内容',
	'reply_content_less'=>'回复内容不得少于5个字',
	'reply_success'=>'回复成功',
	/* admin_task_custom_htm */
	
	'task_communication'=>'客服留言',
	'comment_list'=>'留言列表',
	'proposal'=>'提议',
    'reply_msg'=>'回复留言',
	'sumbit_time'=>'提交时间',		

);
	