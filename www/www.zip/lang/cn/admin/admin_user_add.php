<?php
/**
 * 用户管理
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2011-12-29 上午09:03:39
*/
$lang=array(
/*admin_user_add.php*/
      'add_member'=>'添加用户',
      'user_creat_success'=>'用户创建成功',
      'system_admin'=>'系统管理员',
      'give_your_cash_account_added'=>'给您的现金帐户追加了',
      'give_your_cash_account_deduct'=>'给您的现金帐户扣除了',
      'edit_member'=>'编辑用户',

/*admin_user_add.htm*/
      'user_manage'=>'用户管理',
      'user_group'=>'用户组',
      'ordinary_user'=>'普通用户',
      //'member_manage'=>'用户管理',
      'edit_member_info'=>'编辑用户资料',
      'add_member_info'=>'添加用户资料',
      'please_input_limit_char_username'=>'请输入2-20的字符或者汉字的用户名',
      'username_can_not_null'=>'用户名不能为空',
      'if_no_input_please_null'=>'如果不填请留空。',
      'confirm_password'=>'确认密码',
      'number'=>'号码',
      'please_input_password'=>'请输入密码',
      'password_limit'=>'密码限定为6-20位',
      'please_input_password_again'=>'请再次输入密码',
      'confirm_password_input_not_consistent'=>'确认密码输入不一致',
      'format_error'=>'格式错误',
      'please_input_right_email'=>'请输入正确邮箱',
      'please_input_right_phone'=>'请输入正确电话',
      'please_input_right'=>'请输入正确',
      'experience_value'=>'经验值',
      'user_money'=>'用户金额',
      'cash_coupon'=>'代金券',
      'please_input_limit_integer'=>'请输入1-8位的整数',
      'input_error'=>'输入错误',
      'please_input_this_interval_decimal'=>'请输入在此区间的小数',
	  'is_recommend'=>'是否推荐',
	  'recommend_tip'=>'推荐后将在首页商城模块展示'
);