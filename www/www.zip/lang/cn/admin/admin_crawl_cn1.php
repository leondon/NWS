<?php
/**
*系统日志
*@author deng
*@version KPPW 2.0
*@charset:GBK
*2011-12-15 下午01:50:35
*/
$lang=array(
/*admin_crawl_cn1.php */
      'empty_crawl_data_success'=>'清空爬网数据成功',
      'empty_crawl_data'=>'清空爬网数据',
		'delete_crawl_data'=>'删除爬网数据',
		'mulit_delete_data'=>'批量删除数据',
/*admin_crawl_cn1.htm*/      
      'cn1'=>'一品威客网',
      'operator'=>'操作员',
      'log_time'=>'日志时间',
      'warm_prompt'=>'温馨提示：请慎重操作',
      'user_groups'=>'用户组',
      'confirm_to_empty_all_logs'=>'确认清空所有日志吗?',
      'empty_log'=>'清空日志',
      'log_content'=>'日志内容',
);