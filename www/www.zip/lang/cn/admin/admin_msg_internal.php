<?php
/**
 * 站内短信
 * @author hr
 * @version kppw2.0
 * 2011-12-13  下午03:54:40
 */

	$lang = array(
	
	/* admin_msg_internal.php */
	'sms_internal_config_success' => '站内短信发送配置保存成功',
	'msg_config_log'=>'短信配置',
	/* admin_msg_internal.htm */
	'sms_internal_tpl_title' => '短信模板',
	'sms_config' => '模板列表',
	'sms_tpl_config_edit' => '模板编辑',
	'sms_send_config_manage' => '短信发送配置管理',
	'config_num' => '配置编号',
	'config_name' => '配置名称',
	'edit_tpl' => '编辑模板'
	
	);