<?php
/**
 * @技能管理
 * @author deng
 * @2011-12-13-下午05:37:32
 * @charset:GBK
 * @version KPPW 2.0
 */
$lang=array(
/*admin_task_skill.htm*/
      'add_time'=>'添加时间',
      'skill_list'=>'技能列表',
      'delete_skill'=>'删除了技能',
	  'mulit_delete_skill'=>'批量删除了技能',
      'you_comfirm'=>'你确定要'

);

