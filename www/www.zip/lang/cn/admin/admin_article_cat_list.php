<?php
/**
 * 咨询模块文章分类管理页语言包
 * @author hr
 * @version kppw2.0
 * 2011-12-13  上午10:57:31
 */
$lang = array(
/* admin_article_cat_list.htm */
	'cat_list' => '分类列表',
	'article_manage'=>'文章管理',
	'cat_manage'=>'分类管理',
	'cat_add' => '分类添加',
	'add_son_cat' => '添加子类',
	'are_you_comfirm' => '你确定要',
	'increase_parent_node'=>'增加父节点',
/* admin_article_cat_list.php */
	'mulit_edit_cate'=>'批量编辑分类',
	'delete_cate'=>'删除分类',
	'mulit_delete_cate'=>'批量删除分类',
	'edit_cate_order'=>'编辑分类排序',
	'cate_delete_successfully' => '分类删除成功',
	'first_classification_can_not_be_deleted' => '一级分类无法删除',
	'cate_does_not_exist_delete_fail' => '分类不存在，删除失败',

);