<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2011-12-27 上午09:56:37
*/
$lang=array(
/*admin_prom_item_edit.php*/
      'edit_prom_material'=>'编辑推广素材',
      'prom_material_edit_success'=>'推广素材编辑成功',
      'add_prom_material'=>'添加推广素材',
      'prom_material_add_success'=>'推广素材添加成功',
      
      
 /*admin_prom_item_edit.htm*/     
      'edit_material'=>'编辑素材',
      'add_material'=>'添加素材',
      'prom_material_manage'=>'推广素材管理',
      'material_type'=>'素材类型',
      'please_choose_type'=>'请选择类型',
      'choose_type'=>'选择类型',
      'text'=>'文字',
      'prom_name'=>'推广名称',
      'prom_name_can_not_null'=>'推广名称不能为空，长度限制在5-50',
      'prom_name_length_limit'=>'推广名称长度限制在5-50',
      'prom_picture'=>'推广图片',
      'click_view'=>'点击查看',
      'code_and_content'=>'代码与内容',
      'prom_notice'=>'用 [推广地址] 来表示推广的链接地址，[推广链接]来表示带 可点击的链接。',
      'website'=>'网站',
      'add_prom_item'=>'增加推广项目',


);