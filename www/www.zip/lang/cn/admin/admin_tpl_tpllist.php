<?php
/**
 * @copyright keke-tech
 * @author S
 * @version v 2.0
 * 2011-12-15
 */
$lang = array(
//admin_tpl_tpllist_htm

    'tpl_manage'=>'模板管理',
	'tpl_file_list'=>'模板文件列表',
	'file'=>'文件名',
//admin_tpl_edit_tpl_htm
	
	'tpl_edit'=>'编辑模板',
	'tpl_url'=>'模板存放地址',
	'enter_tpl_name'=>'请输入模板名',
);

