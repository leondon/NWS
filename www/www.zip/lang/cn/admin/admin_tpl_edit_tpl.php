<?php
/**
*模板管理
*@author deng
*@version KPPW 2.0
*@charset:GBK
*2011-12-15 下午03:27:41
*/

$lang=array(
/*admin_tpl_edit_tpl.htm*/
      'template_manage'=>'模板管理',
      'edit_template'=>'编辑模板',
      'template_store_address'=>' 模板存放地址',
      'please_enter_template_name'=>'请输入模板名',
	  'file'=>'文件:',
	  'can_not_write_please_check'=>'不可写，请检查',
	  'tpl_edit_success'=>'模板编辑成功',
);