<?php
$lang=array(
		
    'mutual_evaluation_list'=>'互评列表',
	//'role_relationship_notice'=>'角色雇主与买家等同，角色威客与卖家等同,前端显示会根据不同的角色显示对应的头衔与图片',
	'mark_tips'=>'威客：中标金额*(X)评的百分比=+威客的能力值;雇主:任务金额*(X)评的百分比=+雇主的信誉值;X=好，中，差评',	
	'credit_rules_list'=>'信誉规则列表',
	'delete_mark_config'=>'删除互评配置',
	);
 
	




