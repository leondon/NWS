<?php
$lang = array(
/*admin_permission.php*/
	'error_model_param'=>'错误的模型参数',
	'error_rights_project'=>'错误的权限项目',
	'rights_edit_successfully'=>'权限编辑成功',
/*admin_permission.htm*/
	'rights_edit'=>'权限编辑',
	'nisonshift_model'=>'所属模型',
	'condition_limit'=>'条件限制',
	'user_must_pass_synchronously'=>'用户必须同时通过',
	'only_can'=>'才能',
	'honor'=>'头衔为',
	'de_user'=>'的用户',
	'forbid'=>'禁止',
	'no_limit'=>'不限',
	'limit_every_24hour'=>'每24小时限定',
	'not_limit'=>'无限',
	'limited'=>'有限',
	'limit_times_large_one'=>'限制次数不得小于1次',
	'choose_button_if_not'=>'如不填写请选择【不限】按钮',

);
