<?php
/**
 * @维权管理
 * @author deng
 * @2011-12-14 上午10:04:32
 * @charset:GBK
 * @version KPPW 2.0
 */

$lang=array(
/*admin_trans_rights.htm*/
		'trans_rights'=>'交易维权',
		'only_delete_not_accept'=>'只能删除未受理的',
		'delete_it_carefully_confirm'=>'删除时请仔细确认',
		'submit_time_desc'=>'提交时间递减',
		'submit_time_asc'=>'提交时间递增',
		'process_people'=>'处理人',
		'view_belongs'=>' 查看所属',
		'not_submit_attachment'=>'未提交附件',
		'view_scheme'=>'查看方案',
		'you_comfirm_to'=>'你确定要',
		'only_delete_overdue'=>'只能删除已过期的',
);