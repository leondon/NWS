<?php
/**
 * 咨询模块添加文章页语言包
 * @author hr
 * @version kppw2.0
 * 2011-12-13  上午10:20:13
 */
$lang = array(
/* admin_article_edit.htm */
	'the_title' => '的标题',
	'choose_from' => '请填写来源',
	'from_where'=>'的来源是',
	'upload_image'=>'卦面图片',
	'please_input' => '请输入',
	'choose_category' => '请选择分类',
	'click_to_view_full_size'=>'点击查看原图',
	'category_has_been_selected' => '分类已选择',
	'choose_which_category' => '你准备选择哪类的',
	'please_input_author' => '请填写作者名称',
	'please_input_your_author' => '填写文章作者的名称？',
	'upload_fail_file_too_large'=>'上传的图片太大',
	'del_success'=>'删除成功',
	'some_restrictions_about_title' => '标题输入有误，长度在3-100个字符串之间',
	'allowed_to_be_uploaded'=>'允许上传.jpg,.png,.gif,.jpeg,.bmp格式，文件大小不超过',
	'add_art'=>'添加文章',
	'edit_art'=>'编辑文章',

);