<?php

$lang  = array (
/*admin_user_custom_list.php*/
	'user_no_exit'=>'该用户不存在',
	'no_operate_again_for_user_is_kf_'=>'该用户已经是客服，请勿重复操作',
	'set_you_for_kf'=>'设置将您的设置为客服',
	'add_kf_successfully'=>'客服添加成功',
	'delete_kf'=>'删除客服',
	'more_delete_kfs'=>'批量删除客服',
/*admin_user_service_list.htm*/
	'user_status'=>'用户状态',
	'normal'=>'正常',
	'users'=>'用户组',

/*admin_user_service_add.htm*/
	'kf_manage'=>'用户组',
	'kf_list'=>'组员列表',
	'add_new_kf'=>'设置用户组',
	'user_id_no_empty'=>'用户ID不能为空',



);