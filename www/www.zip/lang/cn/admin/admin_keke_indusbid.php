<?php
$lang = array(


	'industry_bind'=>'行业绑定',
	'local_industry'=>'本地行业',
	'bind'=>'绑定',
	'union_class'=>'联盟分类',
	'has_been_bind_industry'=>'已绑定行业',
	'has_been_bind_union_class'=>'已绑定联盟分类',
	'revoked_bind'=>'撤销绑定',
	'web_design'=>'网站建设',
	'bind_info'=>'点绑定时删除2边的绑定项目   建立绑定关系显示在已绑定列表   并入库存储绑定关系 点解除时删除该行  并在2个列表上回复下拉项',
	'file_type_wrong'=>'文件类型不对',
	'web_development'=>'网站开发',
	'class'=>'分类',

);