<?php
/**
* 后台登录处理
*@author deng
*@version KPPW 2.0
*@charset:GBK
*2011-12-26 下午02:43:47
*/
$lang=array(
/*admin_login.php*/
      'you_already_login'=>'您已登陆',


/*admin_login.htm*/
	'admin_keke_sys'=>'后台管理 - 客客专业威客系统',
      'keke_professional_witkey_system'=>'客客专业威客系统',
      'system_manage'=>'系统管理',
      'keke_info_technology_company'=>'武汉客客信息技术有限公司',
      'username_can_not_null'=>'用户名不能为空',
      'please_input_right_login_username'=>'请填写正确登录账号',
      'password_can_not_null'=>'密码不能为空',
      'please_input_right_login_password'=>'请填写正确登录密码',
      'you_have'=>'您还有',
      'times_try_chance'=>'次尝试机会!',
      'screen_lock_status'=>'锁屏状态',
      'login_fail_notice'=>'登录失败,连续失败5次，系统限制您1个小时后才可登录!'
);