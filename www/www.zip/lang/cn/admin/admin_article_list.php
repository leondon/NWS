<?php
/**
 * 咨询模块文章管理页语言包
 * @author hr
 * @version kppw2.0
 * 2011-12-13  上午09:03:30
 */

$lang = array(

/* admin_article_list.php */
	'edit_art_order'=>'编辑文章排序',
	'recovery_articles' => '恢复文章',
	'mulit_delete_articles' => '批量删除文章',
	'mulit_recovery_articles' => '批量恢复文章',
	'article_title' => '文章标题',
	'default_display' => '正常显示',
	'static'=>'静态化',
	'static_file_update'=>'静态文件更新',
	'start_update_static_file'=>'开始更新静态文件',
	'static_file_update_not_operation'=>'静态文件更新中,请勿操作',
);