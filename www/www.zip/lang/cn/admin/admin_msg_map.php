<?php
$lang = array(
/**admin_msg_map.php**/
	'edit_map_api'=>'编辑地图接口',
	'map_api_edit_success'=>'地图接口编辑成功',
	'map_api_edit_fail'=>'地图接口编辑失败',
/**admin_msg_map.htm**/
	'map_api'=>'地图接口',
	'api_select'=>'接口选择',
	'google_map'=>'谷歌地图',
	'enter_google_map_api_key'=>'输入谷歌地图API密钥',
	'click_apply'=>'点击申请',
	'baidu_map'=>'百度地图',
	'enter_baidu_map_api_key'=>'输入百度地图API密钥',
	'baidu_map_description'=>'百度地图v1.3API地址,此地址无须修改,http://api.map.baidu.com/api?v=1.3',
);