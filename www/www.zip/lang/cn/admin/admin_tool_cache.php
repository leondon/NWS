<?php
/**
*更新缓存
*@author deng
*@version KPPW 2.0
*@charset:GBK
*2011-12-15 上午11:31:41
*/
$lang=array(
/*admin_tool_cache.php*/
      'object_cache_empty'=>'对象缓存清空',
      'template_cache_empty'=>'模板缓存清空',
      'cache_empty'=>'清空缓存',


/*admin_tool_cache.htm*/
      'cache'=>'缓存',
      'update_template_cache'=>'更新模板文件缓存',
      'template_cache_notice'=>'模板文件缓存   
                当你通过FTP上传或者在线编辑等操作修改了站点模板后，如果显示页面没有及时显示出修改后的效果，你可以通过手工模板缓存操作进行立即更新',
      'update_object_cache'=>'更新对象文件缓存',
      'object_cache_notice'=>'对象文件缓存包括系统配置缓存，模块数据缓存等等
                    站点开启模块数据缓存功能后，站点区块显示数据（如最新文章、最新分类等区块数据）都将进行缓存，以大大提高站点访问速度，降低服务器负载
                    对象文件缓存缓存一般情况下都会在后台修改设定后自动更新，一般不需要手工更新。如果站点运行过程中出现错误，你可以尝试更新本缓存',
      'update_cache_now'=>'立即更新缓存' ,
  	  'list'=>'列表',
);