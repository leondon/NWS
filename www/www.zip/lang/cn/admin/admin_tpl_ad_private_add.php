<?php 
/*
 * @copyright keke-tach
 * @author S
 * @kppw 2.0
 * @2011-12-26
 */
 $lang = array(
//admin_tpl_ad_private_htm
	'add_advertising'=>'广告位添加',
 	'ads_name'=>'广告名称',
 	'range'=>'范围',
 	'user_separated'=>'用户','隔开',
 	'p_size'=>'位置/尺寸',
 	'position_size'=>'位置=>尺寸',
 	'required_number'=>'所需数量',
 	'sample_image_address'=>'示例图片地址',
//admin_tpl_ad_private_add_php
 	'add_submit_success'=>'添加提交成功',
); 
 					