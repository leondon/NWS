<?php
$lang = array(
	'admin_keke_sys'=>'后台管理 - 客客专业威客系统',
	'faster_operate'=>'快捷操作',
	'hello'=>'您好',
	'default_blue'=>'默认蓝',
	'easy_blue'=>'简蓝',
	'bright_purple'=>'亮紫',
	'lock'=>'锁屏',
	'website_home'=>'网站首页',
	'safe_exit'=>'安全退出',
	'manage_home'=>'管理首页',
	'nav_map'=>'导航地图',
	'admin_nav_map'=>'后台网站导航',
	'nav_search'=>'导航搜索',
	'lock_status'=>'锁屏状态',
	'enter_lock_status'=>'已进入锁屏状态',
/*admin_index.htm*/
    'add_faster_operate'=>'添加快捷操作',
    'please_choose_add_faster_operate'=>'请选择待添加快捷方式',
    'delete_faster_operate'=>'移除快捷操作',
	'refresh'=>'刷新',
	'clear_cache'=>'清除缓存',

);