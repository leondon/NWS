<?php
/**
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2011-12-27 上午09:22:37
*/
$lang=array(
/*admin_prom_event.php*/
      'delete_fail_please_choose_operate'=>'删除失败,请选择操作项',
      'mulit_delete_fail_please_choose'=>'批量删除失败,请选择操作项',

/*admin_prom_event.htm*/
      'prom_finance_manage'=>'推广财务管理',
      'finance_manage'=>'财务管理',
      'promoter'=>'推广人',
      'be_prom_people'=>'被推广人',
      'event_type'=>'事件类型',
      'all'=>'所有',
      'event_time'=>'产生时间',
      'item'=>'项目',
      'upline'=>'上线',
      'downline'=>'下线',
      'prom_money'=>'推广金额',
      'prom_event'=>'推广事件',
      'no_settlement'=>'暂未结算', 
      'has_fail'=>'已失败',

);