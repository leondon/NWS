<?php
/**
 * @维权管理
 * @author deng
 * @2011-12-14 上午10:04:32
 * @charset:GBK
 * @version KPPW 2.0
 */
$lang=array(
/*admin_trans_process.php*/
      'parameters_error_not_exist'=>'参数错误,不存在的',
      'process_success'=>'处理成功',
      'process_over'=>'处理结束',
	  'deal_object_del'=>'处理对象被删除',

/*admin_trans_process.htm*/
      'belong_to_task'=>'所属任务',
      'belong_to_goods'=>'所属商品',
      'sponsor'=>'发起人',
      'apply_status'=>'申请状态',
      'explain'=>'说明',
	  'no_submit_attachment'=>'未提交附件',
      'untenable_reason'=>'不成立理由',
      'untenable'=>'不成立',
      'reply_not_less_than_ten'=>'回复内容不得少于10字',
      'comfirm_to_tips'=>'确认提示',
      'comfirm_to_not'=>'确认不受理此',
	  'confirm_to'=>'确认受理此',
      'reason_for'=>'理由为',
      'untenable_notice'=>'不成立理由不得少于20字,此内容将通知用户，请谨慎填写',
	  'hirer_deposit_cash'=>'雇主诚意金',
	  'wiki_deposit_cash'=>'威客诚意金',
	  'host_amount'=>'托管佣金',
	  'all_return'=>'全部退还',
	  'all_deduct'=>'全部扣除',
	  'part_refund'=>'部分退还',
	  'according_the_task_config'=>'将按照任务配置扣除',
	  'deposit_cash'=>'诚意金',
	  'both_side_dealing'=>'双方分配',
	  'hirer_dealing'=>'雇主分配',
	  'wiki_dealing'=>'威客分配',
	  'hirder_deposit_cash'=>'雇主诚意金;',
	  'wiki_deposit_cash'=>'威客诚意金;',
	  'hirder_deposit_cash_all_refund'=>'全部退还雇主佣金;',
	  'commission_allocation_is_not_complete'=>'佣金分配不完全,请仔细确认',

	  'do_not_choose_if_not_deducted'=>'如不扣除请勿选择此项',
	  'do_not_choose_if_not_freeze'=>'如不冻结请勿选择此项',
);