<?php
/**
 * 咨询模块文章添加分类页语言包
 * @author hr
 * @version kppw2.0
 * 2011-12-13  上午11:18:21
 */
$lang = array(
/* admin_article_cat_edit.php  */
		'please_enter' => '请填写',
		'cat_name' => '分类名称',
		'cat_list' => '分类列表',
		'cat_add' => '分类添加',
		'cat_edit' => '分类编辑',
		'cat_manage'=>'分类管理',
		'father_cat' => '父分类',
		'edit_article_cat' => '编辑文章分类',
		'add_article_cat' => '添加文章分类',
		'select_father_cat' => '请选择父分类',
		'cat_what' => '你准备哪类的父分类呢',
		'input_cat_name' => '请输入分类的名称',
		'edit_article_cat_success' => '文章分类编辑成功',
		'add_article_cat_success' => '文章分类添加成功',
		'cat_name_limit' => '分类名称不能为空，长度限制在3-20',
		'category_order'=>'文章分类的排序',
);