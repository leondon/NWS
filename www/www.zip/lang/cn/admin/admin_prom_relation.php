<?php
/**
 * 推广关系
*@author deng
*@version KPPW 2.0
*2011-12-27 下午02:31:49
*/
$lang=array(
/*admin_prom_relation.php*/
      'delete_prom_relation'=>'删除推广关系',
      'delete_fail_please_choose_operate'=>'删除失败,请选择操作项',
      'mulit_delete_prom_relation'=>'批量删除推广关系',
      'mulit_delete_fail_please_choose'=>'批量删除失败,请选择操作项',



/*admin_prom_relation.htm*/
      'prom_relation_manage'=>'推广关系管理',
      'relation_manage'=>'关系管理',
	  'show_reslut'=>'结果显示',
      'prom_time'=>'推广时间',
      'upline'=>'上线',
      'downline'=>'下线',
      'prom_type'=>'推广类型',
      'relation_status'=>'关系状态',
      'on_time'=>'产生时间',
      'add_relation'=>'添加关系'
);



