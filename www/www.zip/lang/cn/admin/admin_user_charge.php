<?php
/**
 * 用户管理
*@copyright keke-tech
*@author deng
*@version KPPW 2.0
*2011-12-29 上午09:03:39
*/
$lang=array(
	'uid'=>'UID/用户名',
	'charge_cash'=>'充值金额',
	'exisits_cash'=>'现金',
	'cash_coupon'=>'代金券',
	'charge_reason'=>'充值事由',
	'please_input_limit'=>'请填写待充值用户的UID或 用户名',
	'username_uid_can_not_null'=>'用户UId或用户名不得为空',
	'please_input_cash'=>'请填写充值金额',
	'cash_can_not_null'=>'充值金额不得为空或字符,请填写正数',
	'none_exists_uid_or_username'=>'不存在的用户名或UID',
	'charge_success'=>'手动充值成功',
	'charge_fail'=>'手动充值失败',
	'user_deduct_limit'=>'警告，此用户最多可扣除',
	'will_recharge'=>'充值现金: ',
	'will_deduct'=>'扣除现金: ',
	'recharge'=>'添加 ',
	'deduct'=>'扣除 ',
	'pass_validation'=>'请先验证用户信息',
	'usefull_balance'=>'可用现金: ',
	'usefull'=>'可用',
	'user_tips'=>'用户的编号或用户名来查找用户',
	'valid'=>'验证',
	'account_info'=>'账户信息',
	'recharge_balance_tips'=>'给指定用户充值的现金数值,为负数时表示扣除。',
	'recharge_to_user'=>'给指定用户充值',
	'value_negative_tips'=>'数值,为负数表示扣除。',
);