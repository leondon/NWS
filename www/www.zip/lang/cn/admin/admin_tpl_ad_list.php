<?php 
/*
 * @copyright keke-tach
 * @author S
 * @kppw 2.0
 * @2011-12-26
 */
 $lang = array(
//admin_tpl_ad_list_htm 
 
 	'ads_manage'=>'广告管理',
 	'advertising'=>'广告位',
 	'ads_list'=>'广告列表',
 	'ads_group'=>'广告组',
    'top'=>'上',	
 	'bottom'=>'下',	
 	'left'=>'左',
 	'right'=>'右',	
 	'center'=>'中间',	
 	'global'=>'通栏',
 	'ads_id'=>'广告ID',
  	'ads_name'=>'广告名称',
 	'ads_type'=>'广告类型',
 	'ads_id_desc'=>'广告id降序',
  	'ads_id_asc'=>'广告id升序',
 	'end_time_desc'=>'结束时间降序',
 	'end_time_asc'=>'结束时间升序',
  	'ads_title'=>'广告标题',
 	'start_time'=>'起始时间',
 	'end_time'=>'终止时间',
 	'station_call'=>'站内调用',
  	'is_available'=>'是否可用',
 	'put_range'=>'投放范围',
 	'available'=>'可用',
 	'not_available'=>'不可用',
 	'copy_code'=>'复制代码',
 	'copy'=>'复制',
	'add_ads'=>'添加广告',
//admin_tpl_ad_list_php
 
  	'delete_ads'=>'删除广告',
 	'ads_delete_success'=>'广告删除成功!',
 	'no_operation'=>'没有进行任何操作',


 );