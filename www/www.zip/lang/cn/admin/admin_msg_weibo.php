<?php
/**
 * 第三方登陆
 * @author hr
 * @version kppw2.0
 * 2011-12-13  下午04:32:38
 */

	$lang = array (
		/* admin_msg_weibo.php */
	'account_from_alipay' => '支付宝',	
	'account_from_sina_wb' => '新浪微博',	
	'account_from_tencent_wb' => '腾讯微博',	
	'account_from_163_wb' => '网易微博',	
	'account_from_sohu_wb' => '搜狐微博',
	'account_from_taobao'=>'淘宝',	
	'oauth_api_config_success' => '站点接口配置成功',
	'oauth_api_config_fail' => '站点接口配置失败',
	'config_interface_log'=>'配置三方登录接口',
	
	  /*admin_msg_weibo.htm */
	'wangyi' => '网易',
	'sohu' => '搜狐',
	'weibo_view'=>'微博关注',
	'click_apply'=>'点击申请',
	'fill_right'=>'填写正确的',
	'wy'=>'网易',
	'api_config_manage' => '接口配置管理',
	'oauth_api_config' => 'OAuth登录配置',
	'open_which_api' => '开启哪些接口',
	'enter_correct_qqappid' => '填写正确的QQappid',
	'qq_api_num' => 'QQ开发者平台提供的api编号',
	'qq_api_app_secret_num' => '开发者平台提供的app_secret编号',
	
	'enter_correct_alipay_appid' => '填写正确的支付宝appid',
	'alipay_api_num' => '支付宝开发者平台提供的api编号',
	'enter_alipay_api_app_secret_num' => '填写正确的支付宝appsecret',
	'alipay_api_app_secret_num' => '支付宝开发者平台提供的app_secret编号',
	
	'enter_correct_taobao_appid' => '填写正确的淘宝appid',
	'taobao_api_num' => '淘宝开发者平台提供的api编号',
	'enter_taobao_api_app_secret_num' => '填写正确的淘宝appsecret',
	'taobao_api_app_secret_num' => '淘宝开发者平台提供的app_secret编号',
	
	
	'enter_sina_api_app_secret_num' => '填写正确的新浪appid',
	'sina_api_num' => '新浪开发者平台提供的api编号',
	'enter_sina_api_app_secret_num' => '填写正确的新浪appsecret',
	'sina_api_app_secret_num' => '新浪开发者平台提供的app_secret编号',
	
	'enter_tencent_api_app_secret_num' => '填写正确的腾讯appid',
	'tencent_api_num' => '腾讯开发者平台提供的api编号',
	'enter_tencent_api_app_secret_num' => '填写正确的腾讯appsecret',
	'tencent_api_app_secret_num' => '腾讯开发者平台提供的app_secret编号',
	
	'enter_163_api_app_secret_num' => '填写正确的网易appid',
	'wangyi_api_num' => '网易开发者平台提供的api编号',
	'enter_163_api_app_secret_num' => '填写正确的网易appsecret',
	'wangyi_api_app_secret_num' => '网易开发者平台提供的app_secret编号',	
	
	'enter_sohu_api_app_secret_num' => '填写正确的搜狐appid',
	'sohu_api_num' => '搜狐开发者平台提供的api编号',
	'enter_sohu_api_app_secret_num' => '填写正确的搜狐appsecret',
	'sohu_api_app_secret_num' => '搜狐开发者平台提供的app_secret编号',	
 

	);