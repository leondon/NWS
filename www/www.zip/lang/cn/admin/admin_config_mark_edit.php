<?php
$lang= array(
      'rule_manage'=>'规则管理',
	  'credit_rules_manage'=>'信誉规则管理',
	  'add_credit_rules'=>'增加信誉规则',

	  'edit_rules'=>'编辑规则',
	  'add_rules'=>'添加规则',
	  'credit_value'=>'信誉值',
	  'ability_value'=>'能力值',

	  'employer_name'=>'雇主头衔名称(买家)',
	  'witkey_name'=>'威客头衔名称(卖家)',
	  'employer_icon'=>'雇主头衔图标(买家)',
	  'witkey_icon'=>'威客头衔图标(卖家)',

	  'file_format_error'=>'文件格式不对!',
	  'upload_fail_file_too_large'=>'上传失败,可能文件过大<br>'
	  )
	  ;
?>



