<?php
/**
 * @version kppw2.0
 * 2011-12-13  上午11:18:21
 */
$lang = array (
/**amin_msg_attention.php**/
	'weibo_config_view'=>'配置微博关注',
	'weibo_view_config_success'=>'微博关注配置成功',
	'weibo_view_config_fail'=>'微博关注配置失败',
/**amin_msg_attention.htm**/
	'weibo_view'=>'微博关注',
	'login_config'=>'登录配置',
	'weibo_view_list'=>'微博关注列表',
	'view_user_weibo'=>'要关注的用户微博名称 如',
	'num_part'=>'为数部分',
	'red_part'=>'红色部分',
	'wangyi'=>'网易',
	'souhu'=>'搜狐',
);
