<?php
$lang = array(
	'union_api_config_manage'=>'联盟API配置管理',
	'union_api_config'=>'联盟API配置',
	'union_api_id'=>'联盟提供的api编号',
	'union_app_secret_id'=>'联盟提供的app_secret编号',
	'for_task'=>'获取任务',
);