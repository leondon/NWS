<?php
/**
 * this not free,powered by keke-tech
 * @author jiujiang
 * @charset:GBK  last-modify 2011-12-16-上午11:04:09
 * @version V2.0
 */
$lang = array(
//admin_tpl_editfeed_php

		'add_fail_select_type'=>'添加标签失败,请选择feed类型!',
		'add_fail_alerady_exists'=>'添加标签失败,该标签已存在!',
		//admin_tpl_editfeed_data_thm

		'feed_manage'=>'feed管理',
		'dns_manage'=>'动态管理',
		'tag_call'=>'标签调用',
		'dns_edit'=>'动态编辑',
		'dns_id'=>'动态ID',
		'on_time'=>'动态生成时间',
		'dns_type'=>'动态类型',
		'dns_title'=>'动态标题',
		'return_list'=>'返回列表',
		//admin_tpl_feed_data_htm
		
		'dns_call'=>'动态调用',
		'fuzzy_query'=>'表示支持模糊查询',
		'default_id_sort'=>'默认id排序',
		'dns_name'=>'动态名称',
		'dns_names'=>'动态名',
		'dns_list'=>'动态列表',
		'event_title'=>'事件标题',
		'event_type'=>'事件类型',
/*admin_tpl_editfeed_manage.htm*/	
        'tag_id'=>'标签编号',
        'order_id_sort'=>'编号排序',	
        'tag_names'=>'标签名称',
	    'dns_tag_list'=>'动态标签列表',
	    'page_call_code'=>'内部调用代码',
	    'js_call_code'=>'js调用代码',
	    'preview'=>'预览',
	    'create_tag'=>'创建标签',
        'comfirm_want_delete_select'=>'确定要删除所选?',
 
);