<?php
/**
* 数据库备份
*@author deng
*@version KPPW 2.0
*@charset:GBK
*2011-12-15 上午10:54:31
*/
$lang=array(
/*admin_tool_dbbackup.php*/
      'note'=>'注',
      'generated_database'=>'生成的数据库*.sql文件存放在网站根目录/data/backup/下',
      'are_the_backup_data_table'=>'正在备份数据表',
      'table_name'=>'表名',
      'backup_database'=>'备份数据库',
      'backup_success_name_is'=>'数据库备份成功,文件名为',
		'backup_success'=>'数据备份成功',
		'backup_fail'=>'数据库备份失败',
      'backup_fail_please'=>'数据库备份失败,请',
      'to_operate'=>'重新操作',


/*admin_tool_dbbackup.htm*/
      'database_name'=>'数据库名',
      'backup_now'=>'立即备份',
	  'building'=>'数据备份中,请稍候...',
	  'backup_table'=>'备份数据表',

);