<?php
/**
 * @todo 提现审核信息
 * @author hr
 * @version kppw2.0
 * @encoding GBK
 * 2011-12-14 下午02:33:03
 */
  
	$lang = array(
	
		/* admin_finance_withdraw_info.htm */
		'withdraw_list' => '提现列表',
		'withdraw_audit_info' => '提现信息审核',
		'withdraw_er' => '提现申请人',
		'withdraw_cash' => '提现金额',
		'withdraw_time' => '申请时间',
		'case_status' => '受理状态',
		'case_pass' => '已受理',
		'case_not_pass' => '未受理',
		'collection_method' => '收款方式',
		'beneficiary_account' => '收款帐号',
		'comfirm_to_pass' => '确认要审核么',
		'just_delete' => '直接删除',
//		'pass_audit' => '通过审核',（没有收索到）
	    
	    'mention_now_info_audit'=>'提现信息审核',
	    'carry_applicant'=>'提现申请人',
	    'application_time'=>'申请时间',
	    'accepts_state'=>'受理状态',
	    'payment_method'=>'收款方式',
	    'payment'=>'确认打款',
	    'confirmation'=>'确认要',
	    'me'=>'么',
	);