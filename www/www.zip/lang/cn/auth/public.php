<?php

$lang = array(
	'cash'=>'费用',

	'email_auth'=>'邮箱认证',
	'id_card'=>'身份证号',
	'img_missing'=>'图片丢失',
	'dear'=>'亲爱的',
	'hello'=>':您好',
);