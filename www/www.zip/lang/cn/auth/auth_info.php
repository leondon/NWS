<?php
/**
 * 认证详细表页语言包
 * @version kppw2.0
 * @author xl
 * @2011-12-29
 */
$lang = array(
/**(bank)auth_info.htm**/
	'detail_info'=>'详细信息',
	'payment_type'=>'支付类型',
	'auth_list'=>'认证列表',
	'payment_tool'=>'支付工具',
	'payment_account'=>'支付账号',
	'bank_name'=>'银行名称',
	'open_account_place'=>'开户行所在地',
	'pen_account_name'=>'开户行名称',
	'bank_account'=>'银行账号',
	'open_account_name'=>'开户帐号名称',
	'admin_give_cash'=>'管理员打款金额',
	'give_cash_time'=>'打款时间',
	'give_cash_user'=>'给用户打款',
	'user_gain_cash'=>'用户收款金额',
	'validity'=>'有效期',
	'lifetime_validity'=>'终生有效',
	'to'=>'至',
	'online_payment'=>'在线支付',
	'downline_payment'=>'线下支付',
/**(bank)auth_info.php**/
	'alipay'=>'支付宝',
	'tenpay'=>'财付通',
	'payment_online'=>'网银在线',
	'abc'=>'中国农业银行',
	'cbc'=>'中国建设银行',
	'icbc'=>'中国工商银行',
	'cmbc'=>'招商银行',
	'ctb'=>'交通银行',
	'spdb'=>'浦发银行',
	'cmbc'=>'中国民生银行',
	'ecitic'=>'中信银行',
	'psbc'=>'中国邮政储蓄银行',
	'cib'=>'兴业银行',
	'hxb'=>'华夏银行',
	'bank_auth_notice'=>'银行认证打款通知',
	'admin_give_cach_notice'=>'管理员已经打款到您的账户，请及时查收，并在',
	'auth_center'=>'认证中心',
	'confirm_gain_cach'=>'确认收款金额',
	'give_cach_success'=>'打款金额设置成功',

);