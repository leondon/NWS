<?php
$lang = array(
	'confirm'=>'确定要',
	'prom_bid'=>'推广中标',
	'work_unbid'=>'稿件淘汰',
    'freeze_task_success'=>'冻结任务成功',
    'freeze_task_fail'=>'冻结任务失败',
    'unfreeze_task_success'=>'任务解冻成功',
    'unfreeze_task_fail'=>'任务解冻失败',
    'task_recommend_success'=>'任务推荐成功',
    'task_recommend_fail'=>'任务推荐失败',
    'cancel_recommend_success'=>'取消推荐成功!',
    'cancel_recommend_fail'=>'取消推荐失败!',
	'deduction'=>'扣除',

);