<?php
/**
 * 多人悬赏页语言包
 * 数组键的定义:
 * 单词与单词之间必须用下划线来连接,首字母必须用小写，适用于所有的lang数组；
 * @version kppw2.0
 * @author S
 * @2011-12-23
 */
$lang = array(
//task_list_htm

	'reward_task_manage'=>'悬赏',
	'please_choose_task_status'=>'请选择任务状态',
	'reward_task_list'=>'悬赏任务列表',
	'recommended'=>'[荐]',

//task_list_php

	'delete_task'=>'删除任务',
	'task_link'=>'任务链接',
	'audit_success'=>'审核成功',
	'website_name'=>'网站名称',
	'tips_about_delete_failure'=>'删除失败,可能是该任务当前状态不可删除'

);