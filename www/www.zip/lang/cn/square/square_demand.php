<?php
$lang = array (
		"pub_request_by_me" => "我发布的需求",
		"free_task" => "免费任务",
		"need_task" => "赏金任务",
		"has" => "有",
		"click_view" => "条新动态，点击查看",
		"need" => "需求",
		"age" => "前",
		"just" => "刚刚",
		"pub" => "发布",
		"fee" => "赏金",
		"from" => "来自",
		"free_goods" => "免费服务/商品",
		"bid" => "投标",
		"message" => "留言",
		"favor" => "收藏",
		"tool_box" => "工具箱" 
);