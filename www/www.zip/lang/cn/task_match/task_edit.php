<?php
/**
 * 单人悬赏页语言包
 * 数组键的定义:
 * 单词与单词之间必须用下划线来连接,首字母必须用小写，适用于所有的lang数组；
 * @version kppw2.0
 * @author S
 * @2011-12-23
 */
$lang = array(
//task_edit_htm

	'reward_task_manage'=>'悬赏',
	'reward_task'=>'悬赏任务',
	'is_recommend_task'=>'是否推荐此任务',
	'img_upload'=>'图片上传',
	'expiration_time'=>'到期时间',
	'task_description'=>'任务描述',
	'please_select_category'=>'请选择分类',
	'classification_has_been_select'=>'分类已经选择',
//task_edit_php

	'edit_task'=>'编辑任务',
	'edit_your_task'=>'编辑了您的任务',
	'task_operate_success'=>'任务操作成功',

);