<?php
/**
 * 普通招标任务交易维权页语言包
 * @version kppw2.0
 * @author deng
 * 2011-12-22
 */
$lang = array(
/*task_process.php*/
      'operate_complete'=>'操作完成',
/*task_process.htm*/


      'belong_to_task'=>'所属任务',
      'the_promoters'=>'发起人',
      'apply_status'=>'申请状态',
      'explain'=>'说明',
      'no_submit_attachment'=>'未提交附件',
      'people_surplus'=>'人剩余',
      'deduction'=>'扣除',
      'untenable_reason'=>'不成立理由',
      'process'=>'处理',
      'untenable'=>'不成立',
      'warning_not_choose_process_scheme'=>'警告,你并没有选择处理方案',
      'warning_fill_in_deduction_point'=>'警告，请填写扣除点数',
      'waring_deduction_point_not_negative'=>'警告，扣除点数不支持负数',
      'waring_deduction'=>'警告，扣除',
      'max_is'=>'最大为',
      'waring_fill_in_freeze_day'=>'警告，请填写冻结天数',
      'freeze_user'=>'冻结用户',
      'confirm_report'=>'确认提示',
      'your_current_process_scheme_is'=>'您当前的处理方案为',
      'untenable_notice'=>'不成立理由不得少于20字,此内容将通知用户，请谨慎填写',
      'confirm_not_process'=>'确认不受理此',
      'record_reason_is'=>'记录,理由为'
);