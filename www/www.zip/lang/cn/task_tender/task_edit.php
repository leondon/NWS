<?php
/**
 * 普通招标任务编辑页语言包 
 * @version kppw2.0
 * @author deng
 * @2011-12-22
 */
$lang = array(
/*task_edit.php*/

      'edit_task'=>'编辑任务',
      'edit_your_task'=>'编辑了您的任务',
      'task_operate_success'=>'任务操作成功',
      

/*task_edit.htm*/

      'titile_is_not_null'=>'标题不得为空,5-50字',
      'is_recommend_task'=>'是否推荐此任务',
      'time_show'=>'时间显示',
      'submit_end_time'=>'投稿结束时间',
      'payitem_service'=>'增值服务',
      'total'=>'总计',
      'picture_upload'=>'图片上传',
      'task_attachment'=>'任务附件',
      'no_attachment'=>'暂无附件',
      'update_money_notice'=>'修改金额不得小于任务原金额',
      'task_description'=>'任务描述',

);