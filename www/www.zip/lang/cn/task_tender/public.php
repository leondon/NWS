<?php
$lang = array(
      'recommended'=>'荐',

      'freeze_task_success'=>'冻结任务成功',
      'freeze_task_fail'=>'冻结任务失败',
      'unfreeze_task_success'=>'任务解冻成功',
      'unfreeze_task_fail'=>'任务解冻失败',
      'task_recommend_success'=>'任务推荐成功',
      'task_recommend_fail'=>'任务推荐失败',
      'cancel_recommend_success'=>'取消推荐成功!',
      'choose_end_time'=>'选稿结束时间',

);