<?php
/**
 * 普通招标任务列表页语言包
 * @version kppw2.0
 * @author deng
 * @2011-12-22
 */
$lang = array(
/*task_list.php*/
      'delete_task'=>'删除任务',
      'task_link'=>'任务链接',
      'audit_success'=>'审核成功',
      'website_name'=>'网站名称',


/*task_list.htm*/

      'please_choose_task_status'=>'请选择任务状态',

);