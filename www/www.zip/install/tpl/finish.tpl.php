<!DOCTYPE HTML>
<html>
<head>
<meta charset="<?php echo CHARSET; ?>">
<title><?php echo L('install_complete'); ?>- <?php echo L('kppw_info'); ?></title>
<link href="./tpl/setup.css" rel="stylesheet" type="text/css">
</head>

<body>
	<div class="wrapper">
    	<div class="container">
        	<div class="header">
            </div>
            <div class="content">
            	<div class="setup_four">
                	<div class="menu">
                    	<div class="xy_o"><p><?php echo L('install_agreement') ?></p></div>
                        <div class="huang"><p><?php echo L('evn_etc_test') ?></p></div>
                        <div class="bd_or"><p><?php echo L('admin_form_input') ?></p></div>
                        <div class="wchs"><p><?php echo L('install_complete') ?></p></div>
                    </div>
                </div>
                <div class="cont">
                	<div class="conts">
                    	<div class="gongxi">
                        	<p class="gx"><?php echo L('congratulations'); ?></p>
							<p class="tixing"><?php echo L('complete_tips'); ?></p>
                            <p class="tixing"><?php echo L('delete_the_install_folder') ?></p>
                        </div>
                       <!--  <div><input type="checkbox" id="clear" name="clear" checked="checked" /><span>删除安装目录</span></div>  --><!-- 一点点清洁 -->
                        <div class="anniu"><a href="../index.php"><img src="./tpl/image/jinsy.jpg"></a><a href="../keke" class="houtai"><img src="./tpl/image/jinht.jpg"></a></div>
            </div>
        </div>
	</div>
    <div class="footer">
                    	<div class="foot">
                    	<a href="#" class="yu"></a>
                        <a href="#" class="buttom"></a>
                        </div>
                        <div class="foot_o">
                        <p class="banquan"><?php echo L('copyright'); ?></p>
                        </div>
                    </div>
    		</div>

       </div>

 <script src='../admin/tpl/js/jquery.js' type='text/javascript'></script>
</body>
</html>