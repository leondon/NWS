<?php
$keke_config['db']['dbhost']='localhost';
$keke_config['db']['dbname']='kppw25';
$keke_config['db']['dbuser']='root';
$keke_config['db']['dbpass']='123456';
$keke_config['db']['dbcharset']=DBCHARSET;
$keke_config['db']['tablepre']=TABLEPRE;