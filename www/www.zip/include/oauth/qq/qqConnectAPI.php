<?php
session_start();
require_once(dirname(__FILE__)."/comm/config.php");
require_once(CLASS_PATH."QC.class.php");
