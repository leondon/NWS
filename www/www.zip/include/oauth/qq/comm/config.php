<?php
define("ROOT",dirname(dirname(__FILE__))."/");
define("CLASS_PATH",ROOT."class/");
