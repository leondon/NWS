<?php
  $pay_basic=array("pay_name"=>"财付通",
  					 "type"=>"online",
                     "pay_dir"=>"tenpay",
                     "pay_dev"=>"kekezu",
                     "pay_desc"=>"财付通接口",
                     "img"=>"tenpay.gif",
                     "initparam"=>"seller_id:财付通商户编号;safekey:财付通交易密钥"
               );

?>