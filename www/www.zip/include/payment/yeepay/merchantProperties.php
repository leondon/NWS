<?php

/*
 * @Description 易宝支付产品通用接口范例 
 * @V3.0
 * @Author rui.xin
 */

#	商户编号p1_MerId,以及密钥merchantKey 需要从易宝支付平台获得
/* $p1_MerId			= "10001126856";																										#测试使用
$merchantKey	= "69cl522AV6q613Ii4W6u8K6XuW8vM1N6bFgyv769220IuYe9u37N4y7rI4Pl";		#测试使用
 */
$p1_MerId			= $payment_config['seller_id'];																										#测试使用
$merchantKey	= $payment_config['safekey'];

//var_dump($merchantKey);

$logName	= "YeePay_HTML.log";
