<?php 

  $pay_basic=array("pay_name"=>"支付宝",
  					"type"=>"online",
                    "pay_dir"=>"alipayjs",
                    "pay_dev"=>"kekezu",
                    "pay_desc"=>"即时到账接口",
                    "img"=>"alipayjs.gif",
  					'rate_img'=>'rate_img',
                    "initparam"=>"account:支付宝帐号;account_name:付款人真实姓名;seller_id:合作者身份(PID);safekey:安全效验码(Key)"
               );

?>