<?php

 $pay_basic=array("pay_name"=>"网银在线",
                     "pay_dir"=>"chinabank",
                     "pay_dev"=>"kekezu",
                     "pay_desc"=>"网银在线接口",
                     "img"=>"chinabank.gif",
                     "initparam"=>"seller_id:网银商户编号;safekey:网银交易密匙"
               );
?>