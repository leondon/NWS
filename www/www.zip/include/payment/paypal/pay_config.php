<?php
  $pay_basic=array("pay_name"=>"贝宝",
  					"type"=>"online",
                     "pay_dir"=>"paypal",
                     "pay_dev"=>"kekezu",
                     "pay_desc"=>"即时到账接口",
                     "img"=>"paypal.gif",
                     "initparam"=>"account:贝宝帐号"
               );
               
?>